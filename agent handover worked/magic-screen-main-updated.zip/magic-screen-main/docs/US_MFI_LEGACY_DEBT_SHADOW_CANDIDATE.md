# US MFI Legacy Debt Shadow Candidate

**Status:** implemented locally, not deployed or live-verified. Shadow only.

## Endpoint
`POST /api/fundamentals/legacy-debt-shadow-preview` (Bearer `UNIVERSE_SYNC_TOKEN`, 1-10 active US tickers).
Read-only: D1 SELECTs and SEC Company Facts fetches only. Always returns `production_write:false`, `rankings_changed:false`.
The existing `/legacy-debt-diagnostic` endpoint and the legacy resolver are unchanged.

## Rule
For one accession, fiscal period, USD, consolidated (non-dimensional) instant facts:

`candidate_conventional_debt = LongTermDebtCurrent + LongTermDebtNoncurrent`

- Both components required. Absent is unknown, never zero; a reported 0 is preserved.
- Competing different values for one component => `unresolved_ambiguous`.
- `ShortTermBorrowings`/`ShortTermDebtCurrent` are added only when `DebtCurrent` or `BorrowingsCurrent` equals current + short (proves non-overlap), or the short fact is a reported 0. Otherwise `short_term_borrowings_overlap_unproven`.
- A current aggregate equal to the current component is not double counted; a conflicting aggregate leaves the issuer unresolved.
- Debt-and-lease aggregate tags are surfaced, never used as conventional debt.
- Royalty/other financing and lease concepts are discovered by broad tag-name scan, listed with `included_in_candidate:false`, and flag `scope_review_required_*` / `separate_lease_evidence_not_included`.
- No recognised debt evidence at all => `insufficient_evidence` (not proof of no debt).
- Short-term borrowing status is `not_separately_identified_unknown` when absent.
- `LongTermDebt` is a cross-check only; a mismatch is flagged, not blocking.

Statuses: `candidate`, `candidate_scope_review_required`, `unresolved_insufficient_inputs`, `unresolved_ambiguous`, `insufficient_evidence`.

## Files
`worker/legacy-debt-shadow.mjs`, `worker/legacy-debt-shadow.test.mjs` (18 tests), `worker/index.ts` (route), `.github/workflows/build.yml` (test step).

## Verification (local, 22 Nov 2026)
- `node --test worker/*.test.mjs`: 111 pass, 0 fail.
- `npm run build` and `wrangler deploy --dry-run`: NOT run locally (no network/node_modules in this environment); CI must confirm.
- Not deployed; live endpoint not called. Live BMBL/OTEX/UPWK/BCRX/IRWD results are unverified. Fixtures use the handover's filing values only as test data.
- Production fundamentals, ratios, eligibility and rankings: untouched by design (no write path; test asserts none in the route).
