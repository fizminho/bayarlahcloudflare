// @ts-ignore JavaScript module is contract-tested directly with Node.js.
import { MEMBERSHIP_DDL, SOURCE_MFI, SOURCE_FRONTEND, backfillMfiMemberships, applyMfiSelection, addFrontendStock, removeFrontendStock, invalidateUsRanks, normaliseUsSymbol } from "./universe-membership.mjs";
// @ts-ignore JavaScript module is contract-tested directly with Node.js.
import { runBatchPage, BATCH_STATUS } from "./gemini-batch.mjs";
// @ts-ignore JavaScript module is contract-tested directly with Node.js.
import { assignCombinedRanks, MINIMUM_ELIGIBLE_COHORT } from "./mfi-ranking.mjs";
import { resolveFilingSpecificEbitCandidate } from "./filing-specific-ebit";
import { buildFundamentalsReconciliationPreview } from "./fundamentals-reconciliation";
// @ts-ignore JavaScript module is contract-tested directly with Node.js.
import { classifyDebtReconciliation } from "./debt-reconciliation.mjs";
// @ts-ignore JavaScript module is contract-tested directly with Node.js.
import { diagnoseLegacyDebtFacts } from "./legacy-debt-diagnostic.mjs";
import { resolveLegacyDebtShadow } from "./legacy-debt-shadow.mjs";
// @ts-ignore JavaScript module is contract-tested directly with Node.js.
import { parsePageParams, recordReviewDecision, listReviewHistory, listReviewDecisions, MAX_DECISION_BODY_BYTES, REVIEW_TASKS } from "./gemini-review-ledger.mjs";
// @ts-ignore JavaScript module is contract-tested directly with Node.js.
import { runGeminiAccountingReview, listGeminiAccountingEscalations, getGeminiModelCandidates } from "./gemini-accounting-review.mjs";

interface Env { DB: D1Database; ASSETS: Fetcher; APP_ENV?: string; UNIVERSE_SYNC_TOKEN?: string; MFI_SESSION_COOKIE?: string; GEMINI_API_KEY?: string; GEMINI_MODEL?: string; GEMINI_MIN_REQUEST_INTERVAL_MS?: string; }
const symbols: Record<string, {symbol:string;name:string;market:"MY"|"US";currency:string}[]> = {
  MY: [
    {symbol:"1155.KL",name:"Maybank",market:"MY",currency:"MYR"},{symbol:"1295.KL",name:"Public Bank",market:"MY",currency:"MYR"},
    {symbol:"1023.KL",name:"CIMB Group",market:"MY",currency:"MYR"},{symbol:"5183.KL",name:"Petronas Chemicals",market:"MY",currency:"MYR"},
    {symbol:"5347.KL",name:"Tenaga Nasional",market:"MY",currency:"MYR"},{symbol:"5819.KL",name:"Hong Leong Bank",market:"MY",currency:"MYR"},
    {symbol:"4863.KL",name:"Telekom Malaysia",market:"MY",currency:"MYR"},{symbol:"5225.KL",name:"IHH Healthcare",market:"MY",currency:"MYR"},
    {symbol:"1066.KL",name:"RHB Bank",market:"MY",currency:"MYR"},{symbol:"6888.KL",name:"Axiata Group",market:"MY",currency:"MYR"},
    {symbol:"6033.KL",name:"Petronas Gas",market:"MY",currency:"MYR"},{symbol:"4707.KL",name:"Nestle Malaysia",market:"MY",currency:"MYR"},
    {symbol:"8869.KL",name:"Press Metal",market:"MY",currency:"MYR"},{symbol:"1082.KL",name:"Hong Leong Financial",market:"MY",currency:"MYR"},
    {symbol:"6012.KL",name:"Maxis",market:"MY",currency:"MYR"},{symbol:"1961.KL",name:"IOI Corporation",market:"MY",currency:"MYR"},
    {symbol:"7277.KL",name:"Dialog Group",market:"MY",currency:"MYR"},{symbol:"5681.KL",name:"Petronas Dagangan",market:"MY",currency:"MYR"},
    {symbol:"5285.KL",name:"Sime Darby Plantation",market:"MY",currency:"MYR"},{symbol:"5211.KL",name:"Sunway",market:"MY",currency:"MYR"},
    {symbol:"1818.KL",name:"Bursa Malaysia",market:"MY",currency:"MYR"},{symbol:"5209.KL",name:"Farm Fresh",market:"MY",currency:"MYR"},
    {symbol:"5296.KL",name:"MR D.I.Y. Group",market:"MY",currency:"MYR"},{symbol:"5168.KL",name:"AMMB Holdings",market:"MY",currency:"MYR"},
    {symbol:"4197.KL",name:"Sime Darby",market:"MY",currency:"MYR"},{symbol:"5878.KL",name:"KPJ Healthcare",market:"MY",currency:"MYR"},
    {symbol:"5227.KL",name:"IGB Real Estate Investment Trust",market:"MY",currency:"MYR"},{symbol:"5398.KL",name:"Gamuda",market:"MY",currency:"MYR"},
    {symbol:"5288.KL",name:"UEM Sunrise",market:"MY",currency:"MYR"},{symbol:"5218.KL",name:"Vantris Energy",market:"MY",currency:"MYR"}
  ],
  US: [
    {symbol:"AAPL",name:"Apple",market:"US",currency:"USD"},{symbol:"MSFT",name:"Microsoft",market:"US",currency:"USD"},{symbol:"NVDA",name:"NVIDIA",market:"US",currency:"USD"},
    {symbol:"GOOGL",name:"Alphabet",market:"US",currency:"USD"},{symbol:"AMZN",name:"Amazon",market:"US",currency:"USD"},{symbol:"META",name:"Meta Platforms",market:"US",currency:"USD"},
    {symbol:"AVGO",name:"Broadcom",market:"US",currency:"USD"},{symbol:"TSM",name:"Taiwan Semiconductor ADR",market:"US",currency:"USD"},{symbol:"LLY",name:"Eli Lilly",market:"US",currency:"USD"},
    {symbol:"BRK-B",name:"Berkshire Hathaway",market:"US",currency:"USD"},{symbol:"JPM",name:"JPMorgan Chase",market:"US",currency:"USD"},
    {symbol:"V",name:"Visa",market:"US",currency:"USD"},{symbol:"MA",name:"Mastercard",market:"US",currency:"USD"},
    {symbol:"XOM",name:"Exxon Mobil",market:"US",currency:"USD"},{symbol:"COST",name:"Costco",market:"US",currency:"USD"},
    {symbol:"WMT",name:"Walmart",market:"US",currency:"USD"},{symbol:"ORCL",name:"Oracle",market:"US",currency:"USD"},
    {symbol:"CRM",name:"Salesforce",market:"US",currency:"USD"},{symbol:"NFLX",name:"Netflix",market:"US",currency:"USD"},
    {symbol:"AMD",name:"Advanced Micro Devices",market:"US",currency:"USD"},{symbol:"QCOM",name:"Qualcomm",market:"US",currency:"USD"},
    {symbol:"TXN",name:"Texas Instruments",market:"US",currency:"USD"},{symbol:"CAT",name:"Caterpillar",market:"US",currency:"USD"},
    {symbol:"MU",name:"Micron Technology",market:"US",currency:"USD"},{symbol:"KO",name:"Coca-Cola",market:"US",currency:"USD"},
    {symbol:"PG",name:"Procter & Gamble",market:"US",currency:"USD"},{symbol:"ABBV",name:"AbbVie",market:"US",currency:"USD"},
    {symbol:"ADBE",name:"Adobe",market:"US",currency:"USD"},{symbol:"INTU",name:"Intuit",market:"US",currency:"USD"},{symbol:"TSLA",name:"Tesla",market:"US",currency:"USD"}
  ]
};
const json = (data: unknown, status=200) => new Response(JSON.stringify(data), {status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store","access-control-allow-origin":"*"}});
const US_ACTIVE_UNIVERSE_SQL="EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)";
let membershipReady=false;
async function ensureMembershipSchema(env: Env) {
  if (membershipReady) return;
  await env.DB.batch(MEMBERSHIP_DDL.map((sql:string)=>env.DB.prepare(sql)));
  await backfillMfiMemberships(env.DB);
  membershipReady=true;
}
async function ensureSchema(env: Env) {
  await env.DB.batch([
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS stock_snapshot (
      symbol TEXT NOT NULL, market TEXT NOT NULL CHECK (market IN ('MY','US')), company_name TEXT NOT NULL, currency TEXT NOT NULL,
      price REAL, change_percent REAL, market_cap REAL, earnings_yield REAL, return_on_capital REAL, magic_formula_rank INTEGER,
      shariah_status TEXT NOT NULL DEFAULT 'unverified', shariah_source TEXT, shariah_as_of TEXT,
      data_status TEXT NOT NULL DEFAULT 'unavailable', provider TEXT, updated_at TEXT NOT NULL, PRIMARY KEY (symbol,market)
    )`),
    env.DB.prepare("CREATE INDEX IF NOT EXISTS idx_stock_snapshot_market_rank ON stock_snapshot(market, magic_formula_rank)"),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS refresh_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT, started_at TEXT NOT NULL, completed_at TEXT, status TEXT NOT NULL, message TEXT
    )`)
  ]);
  await env.DB.prepare("CREATE TABLE IF NOT EXISTS stock_master (symbol TEXT NOT NULL, market TEXT NOT NULL, company_name TEXT NOT NULL, currency TEXT NOT NULL, exchange TEXT, sector TEXT, listing_status TEXT NOT NULL DEFAULT 'active', source TEXT NOT NULL, source_updated_at TEXT NOT NULL, PRIMARY KEY(symbol,market))").run();
  await env.DB.prepare("CREATE INDEX IF NOT EXISTS idx_stock_master_market_name ON stock_master(market,company_name)").run();
  await ensureMembershipSchema(env);
  await env.DB.batch([
    env.DB.prepare("CREATE TABLE IF NOT EXISTS sec_company_map (symbol TEXT PRIMARY KEY, cik TEXT NOT NULL, updated_at TEXT NOT NULL)"),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS stock_fundamentals (
      symbol TEXT NOT NULL, market TEXT NOT NULL DEFAULT 'US', cik TEXT, ebit REAL, current_assets REAL,
      current_liabilities REAL, net_ppe REAL, total_debt REAL, cash REAL, market_cap REAL,
      earnings_yield REAL, return_on_capital REAL, fiscal_period TEXT, filed_at TEXT,
      status TEXT NOT NULL, source TEXT NOT NULL DEFAULT 'SEC EDGAR Company Facts', updated_at TEXT NOT NULL,
      PRIMARY KEY(symbol,market)
    )`)
  ]);
  const now = new Date().toISOString();
  for (const market of ["MY","US"] as const) {
    const existing = await env.DB.prepare("SELECT COUNT(*) AS count FROM stock_master WHERE market=?").bind(market).first<{count:number}>();
    if (!existing?.count) {
      const seed = symbols[market].map(item =>
        env.DB.prepare("INSERT OR IGNORE INTO stock_master (symbol,market,company_name,currency,exchange,listing_status,source,source_updated_at) VALUES (?,?,?,?,?,'active','curated-starter-universe',?)")
          .bind(item.symbol,item.market,item.name,item.currency,market==="MY"?"BURSA":"NASDAQ/NYSE",now)
      );
      await env.DB.batch(seed);
    }
  }
}
async function ensureEdgarToolsEvidenceSchema(env: Env) {
  await ensureSchema(env);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS edgartools_filing_evidence (
    symbol TEXT NOT NULL,accession_key TEXT NOT NULL,market TEXT NOT NULL DEFAULT 'US',cik TEXT,accession TEXT,
    fiscal_period TEXT,form TEXT,filed_at TEXT,reporting_currency TEXT,provider_status TEXT NOT NULL,
    provider TEXT NOT NULL DEFAULT 'EdgarTools',provider_version TEXT,generated_at TEXT,payload_json TEXT NOT NULL,
    ingested_at TEXT NOT NULL,PRIMARY KEY(symbol,accession_key))`).run();
}
async function refreshQuotes(env: Env, onlyMarket?: "MY" | "US") {
  await ensureSchema(env);
  const started = new Date().toISOString();
  const log = await env.DB.prepare("INSERT INTO refresh_log (started_at,status,message) VALUES (?, 'running', 'Yahoo Finance quote batch refresh')").bind(started).run();
  let updated=0, failed=0;
  const markets = onlyMarket ? [onlyMarket] : ["MY","US"];
  for (const market of markets) {
    const priority = symbols[market].map(item=>"\u0027"+item.symbol.replaceAll("\u0027","\u0027\u0027")+"\u0027").join(",");
    const candidates = await env.DB.prepare("SELECT m.symbol,m.market,m.company_name AS name,m.currency FROM stock_master m LEFT JOIN stock_snapshot q ON q.symbol=m.symbol AND q.market=m.market WHERE m.market=? AND m.listing_status=\u0027active\u0027 ORDER BY CASE WHEN m.symbol IN ("+priority+") THEN 0 ELSE 1 END,CASE WHEN q.updated_at IS NULL THEN 0 ELSE 1 END,q.updated_at ASC,m.symbol ASC LIMIT 40").bind(market).all<any>();
    for (const item of candidates.results) {
      try {
        const url = "https://query1.finance.yahoo.com/v8/finance/chart/"+encodeURIComponent(item.symbol)+"?range=5d&interval=1d";
        const res = await fetch(url,{headers:{"User-Agent":"Mozilla/5.0 MagicScreen/0.1"}});
        if (!res.ok) throw new Error("Quote provider HTTP "+res.status);
        const payload: any = await res.json();
        const result = payload?.chart?.result?.[0], meta = result?.meta, quote = result?.indicators?.quote?.[0];
        const closes = (quote?.close ?? []).filter((v:any)=>typeof v==="number");
        const price = typeof meta?.regularMarketPrice==="number" ? meta.regularMarketPrice : closes.at(-1) ?? null;
        // chartPreviousClose can refer to the close before the full 5-day chart range.
        // Prefer the previous-session close; otherwise use the penultimate daily candle.
        const previous = typeof meta?.previousClose==="number" ? meta.previousClose
          : typeof meta?.regularMarketPreviousClose==="number" ? meta.regularMarketPreviousClose
          : closes.length>1 ? closes.at(-2)
          : typeof meta?.chartPreviousClose==="number" ? meta.chartPreviousClose : null;
        const change = price!=null && previous!=null && previous>0 ? ((price-previous)/previous)*100 : null;
        if (price==null) throw new Error("No quote in provider response");
        await env.DB.prepare("INSERT INTO stock_snapshot (symbol,market,company_name,currency,price,change_percent,shariah_status,data_status,provider,updated_at) VALUES (?,?,?,?,?,?,'unverified','quote_only','Yahoo Finance',?) ON CONFLICT(symbol,market) DO UPDATE SET company_name=excluded.company_name,currency=excluded.currency,price=excluded.price,change_percent=excluded.change_percent,data_status=CASE WHEN earnings_yield IS NOT NULL AND return_on_capital IS NOT NULL THEN 'fundamentals_calculated' ELSE 'quote_only' END,provider=excluded.provider,updated_at=excluded.updated_at").bind(item.symbol,item.market,item.name,item.currency,price,change,new Date().toISOString()).run();
        updated++;
      } catch { failed++; }
    }
  }
  const cutoff = new Date(Date.now()-24*60*60*1000).toISOString();
  const remaining = await env.DB.prepare("SELECT COUNT(*) AS count FROM stock_master m LEFT JOIN stock_snapshot q ON q.symbol=m.symbol AND q.market=m.market WHERE m.listing_status='active' AND (? IS NULL OR m.market=?) AND (q.updated_at IS NULL OR q.updated_at < ?)").bind(onlyMarket ?? null,onlyMarket ?? null,cutoff).first();
  await env.DB.prepare("UPDATE refresh_log SET completed_at=?,status=?,message=? WHERE id=?").bind(new Date().toISOString(),failed===0?"success":"partial","Updated "+updated+"; failed "+failed+"; stale or missing "+(remaining?.count ?? 0),log.meta.last_row_id).run();
  return {updated,failed,remaining:remaining?.count ?? 0,batchSize:40};
}
// INTENTIONAL: MFI market cap is USD. Keep SEC inputs USD-only until explicit FX conversion
// (with a dated, auditable rate source) exists; missing local-currency facts must stay unavailable.
function secFactValue(facts:any, tags:string[], periodEnd:string, accession:string, annual:boolean): {value:number|null;tag:string|null;filed:string|null} {
  const taxonomies=["us-gaap","ifrs-full"];
  for (const taxonomy of taxonomies) {
  const concepts=facts?.facts?.[taxonomy] ?? {};
  for (const tag of tags) {
    const units=concepts[tag]?.units ?? {};
    // Market capitalisation from MFI is USD. Only use SEC facts explicitly tagged in USD;
    // never mix an issuer's local-currency facts into USD valuation formulas.
    const entries=(units.USD ?? []) as any[];
    const eligible=entries.filter((x:any)=>{
      if (typeof x.val!=="number" || !x.end || !x.filed || !accession || x.accn!==accession || !["10-K","20-F","40-F","10-Q"].includes(x.form)) return false;
// INTENTIONAL: every selected fact must come from the same filing accession as the fiscal-period anchor.
// Matching dates alone can combine restated or comparative facts from different filings.
      if (annual) {
        // INTENTIONAL: annual income-statement facts must match the selected fiscal year end exactly.
        // Do not silently reuse an older EBIT fact when the latest filing uses an unsupported XBRL tag.
        if (x.end!==periodEnd || !x.start) return false;
        const days=(Date.parse(x.end)-Date.parse(x.start))/86400000;
        return days>=330 && days<=400 && ["10-K","20-F","40-F"].includes(x.form);
      }
      // INTENTIONAL: balance-sheet inputs must match the selected annual filing's exact
      // fiscal year-end. Do not substitute an earlier quarter-end or comparative balance sheet.
      return x.end===periodEnd && !x.start;
    }).sort((a:any,b:any)=>b.end.localeCompare(a.end)||b.filed.localeCompare(a.filed));
    if (eligible.length) return {value:eligible[0].val,tag,filed:eligible[0].filed};
  }
  }
  return {value:null,tag:null,filed:null};
}


type EdgarToolsResolution = {
  symbol:string; provider_status:string; accession:string|null; fiscal_period:string|null;
  ebit_candidate:number|null; ebit_method:string|null; ebit_concept:string|null; ebit_label:string|null; ebit_status:string;
  invested_capital_candidate:number|null; invested_capital_status:string;
  reporting_currency:string|null; candidate_roc:number|null; review_flags:string[];
  balance_sheet_candidate_review:Record<string,{
    status:string;candidate_count:number;resolution_hint?:string;automatic_aggregation?:boolean;
    candidates?:Array<{concept?:string;label?:string;fiscal_period?:string;value?:number;row_index?:unknown;
      parent_concept?:string;parent_abstract_concept?:string;level?:number;balance?:string}>;
  }>;
  enterprise_value_candidate_review:{
    status:string; conventional_debt_status:string; conventional_gross_debt_candidate:number|null;
    unrestricted_cash_candidate:number|null; conventional_net_debt_candidate:number|null;
    debt_reconciliation_status:string; approval_status:string;
  };
  overall_status:"review_required"|"unsupported_provider"|"awaiting_evidence";
  production_write:false;
};
function resolveEdgarToolsEvidence(symbol:string, providerStatus:string|null, accession:string|null, fiscalPeriod:string|null, company:any):EdgarToolsResolution {
  if (!company || providerStatus!=="supported") return {
    symbol,provider_status:providerStatus??"awaiting_evidence",accession,fiscal_period:fiscalPeriod,
    ebit_candidate:null,ebit_method:null,ebit_concept:null,ebit_label:null,ebit_status:"not_resolved",
    invested_capital_candidate:null,invested_capital_status:"not_resolved",
    reporting_currency:null,candidate_roc:null,review_flags:[],balance_sheet_candidate_review:{},
    enterprise_value_candidate_review:{status:"not_resolved",conventional_debt_status:"not_resolved",
      conventional_gross_debt_candidate:null,unrestricted_cash_candidate:null,conventional_net_debt_candidate:null,
      debt_reconciliation_status:"not_resolved",approval_status:"review_only_no_production_ev_or_earnings_yield"},
    overall_status:providerStatus==="unsupported_provider"?"unsupported_provider":"awaiting_evidence",production_write:false
  };
  const filing=company.filing??{};
  const period=String(filing.period_of_report??filing.period??"");
  const filingAccession=String(filing.accession_number??filing.accession??"");
  const form=String(filing.form??"");
  const flags:string[]=[];
  if (!accession || filingAccession!==accession) flags.push("filing_accession_mismatch");
  if (!fiscalPeriod || period!==fiscalPeriod) flags.push("fiscal_period_mismatch");
  if (!["10-K","20-F","40-F"].includes(form)) flags.push("ineligible_annual_form");
  const statementRows=company.statements?.income_statement?.rows??[];
  const directRows=statementRows.filter((row:any)=>{
    const concept=String(row?.concept??"");
    return row?.dimension===false && !row?.abstract
      && /(?:^|_)(?:OperatingIncomeLoss|OperatingProfitLoss|ProfitLossFromOperatingActivities)$/.test(concept);
  });
  const directReview=company.direct_operating_income_review??{};
  let ebit:number|null=null;
  let ebitStatus="review_required";
  let ebitMethod:string|null=null;
  if (directRows.length===1) {
    const values=directRows[0]?.values??{};
    const periodValues=Object.entries(values).filter(([key,value]:any)=>
      (key===period || key.startsWith(period+" ")) && typeof value==="number" && Number.isFinite(value)
    );
    const rowValue=periodValues.length===1 ? Number(periodValues[0][1]) : null;
    const reviewedValue=typeof directReview.ebit_candidate==="number" ? directReview.ebit_candidate : null;
    if (rowValue!==null && reviewedValue!==null && Math.abs(rowValue-reviewedValue)<=0.01
      && directReview.method==="direct_reported_operating_income" && directReview.status==="review_only"
      && String(directReview.fiscal_period??"")===period) {
      ebit=rowValue;
      ebitStatus="direct_reported_candidate_review_only";
      ebitMethod="direct_reported_operating_income";
    } else {
      flags.push("direct_ebit_row_and_review_did_not_reconcile");
    }
  } else if (directRows.length===0) {
    const filingSpecificEbit=resolveFilingSpecificEbitCandidate(company,filingAccession,period,directRows.length);
    if (filingSpecificEbit) {
      ebit=filingSpecificEbit.value;
      ebitStatus="filing_specific_reconstruction_review_only";
      ebitMethod=filingSpecificEbit.method;
      flags.push("filing_specific_ebit_reconstruction_requires_manual_approval");
    } else {
      flags.push("direct_operating_income_not_found");
    }
  } else {
    flags.push("multiple_direct_operating_income_rows");
  }
  const invested=company.invested_capital_review??{};
  if (invested.denominator_diagnostics?.negative_working_capital_offsets_at_least_90pct_of_net_ppe===true) {
    flags.push("invested_capital_negative_working_capital_offset_high_risk_manual_review");
  }
  const investedCapital=typeof invested.value==="number" && Number.isFinite(invested.value) ? invested.value : null;
  let investedStatus="review_required";
  if (invested.status==="calculated_review_only" && investedCapital!==null && investedCapital>0
    && invested.method==="current_assets_minus_current_liabilities_plus_net_ppe") {
    investedStatus="positive_denominator_candidate_review_only";
  } else {
    flags.push(investedCapital!==null && investedCapital<=0?"non_positive_invested_capital":"invested_capital_not_resolved");
  }
  const currencyReview=company.reporting_currency_review??{};
  const currency=typeof currencyReview.currency==="string" ? currencyReview.currency : null;
  if (currencyReview.status!=="identified_from_accession_facts" || !currency) flags.push("reporting_currency_not_confirmed");
  for (const flag of (Array.isArray(currencyReview.review_flags)?currencyReview.review_flags:[])) flags.push("currency:"+String(flag));
  const rocReview=company.roc_review??{};
  for (const flag of (Array.isArray(rocReview.review_flags)?rocReview.review_flags:[])) flags.push(String(flag));
  const evReview=company.enterprise_value_scope_review??{};
  for (const flag of (Array.isArray(evReview.review_flags)?evReview.review_flags:[])) flags.push(String(flag));
  const balanceReview=company.balance_sheet_fact_review??{};
  for (const category of (Array.isArray(balanceReview.unresolved_categories)?balanceReview.unresolved_categories:[])) flags.push("balance_sheet:"+String(category));
  const categoryNames={
    current_debt:"current_debt_candidates",noncurrent_debt:"noncurrent_debt_candidates",
    aggregate_debt:"aggregate_debt_candidates",unrestricted_cash:"cash_unrestricted_candidates",
    restricted_cash:"cash_restricted_candidates",short_term_investments:"short_term_investment_candidates",
    current_lease_liabilities:"current_lease_liability_candidates",noncurrent_lease_liabilities:"noncurrent_lease_liability_candidates"
  };
  const balanceSheetCandidateReview:EdgarToolsResolution["balance_sheet_candidate_review"]={};
  for (const [key,name] of Object.entries(categoryNames)) {
    const category=balanceReview.categories?.[name]??{};
    balanceSheetCandidateReview[key]={
      status:typeof category.status==="string"?category.status:"not_found",
      candidate_count:Number.isInteger(category.candidate_count)?category.candidate_count:0,
      resolution_hint:typeof category.resolution_hint==="string"?category.resolution_hint:undefined,
      automatic_aggregation:category.automatic_aggregation===true,
      candidates:Array.isArray(category.candidates)?category.candidates.slice(0,12).map((candidate:any)=>({
        concept:typeof candidate.concept==="string"?candidate.concept:undefined,
        label:typeof candidate.label==="string"?candidate.label:undefined,
        fiscal_period:typeof candidate.fiscal_period==="string"?candidate.fiscal_period:undefined,
        value:typeof candidate.value==="number" && Number.isFinite(candidate.value)?candidate.value:undefined,
        row_index:candidate.row_index,
        parent_concept:typeof candidate.parent_concept==="string"?candidate.parent_concept:undefined,
        parent_abstract_concept:typeof candidate.parent_abstract_concept==="string"?candidate.parent_abstract_concept:undefined,
        level:typeof candidate.level==="number"?candidate.level:undefined,
        balance:typeof candidate.balance==="string"?candidate.balance:undefined
      })):[],
    };
  }
  const candidateNumber=(value:any):number|null=>
    typeof value==="number" && Number.isFinite(value)?value:null;
  const selectionPolicy=evReview.selection_policy_review??{};
  const debtReconciliation=evReview.debt_reconciliation_review??{};
  const debtReconciliationStatus=balanceReview.categories
    ? classifyDebtReconciliation(balanceReview.categories)
    : (typeof debtReconciliation.status==="string"?debtReconciliation.status:"not_resolved");
  const enterpriseValueCandidateReview={
    status:typeof evReview.status==="string"?evReview.status:"not_resolved",
    conventional_debt_status:typeof selectionPolicy.conventional_debt?.status==="string"
      ? selectionPolicy.conventional_debt.status:"not_resolved",
    conventional_gross_debt_candidate:candidateNumber(evReview.conventional_gross_debt_candidate),
    unrestricted_cash_candidate:candidateNumber(evReview.unrestricted_cash_candidate),
    conventional_net_debt_candidate:candidateNumber(evReview.conventional_net_debt_candidate),
    debt_reconciliation_status:debtReconciliationStatus,
    approval_status:typeof selectionPolicy.approval_status==="string"
      ? selectionPolicy.approval_status:"review_only_no_production_ev_or_earnings_yield"
  };
  const uniqueFlags=[...new Set(flags)];
  const candidateRoc=ebit!==null && investedCapital!==null && investedCapital>0 ? Number((ebit/investedCapital*100).toFixed(4)) : null;
  return {
    symbol,provider_status:providerStatus,accession,fiscal_period:fiscalPeriod,
    ebit_candidate:ebit,ebit_method:ebitMethod,
    ebit_concept:ebit!==null && ebitMethod==="direct_reported_operating_income"?String(directRows[0]?.concept??""):null,
    ebit_label:ebitMethod==="filing_specific_statement_subtotal_reconstruction"?"Filing-specific statement subtotal reconstruction (review only)":ebit!==null?String(directRows[0]?.label??""):null,ebit_status:ebitStatus,
    invested_capital_candidate:investedCapital,invested_capital_status:investedStatus,
    reporting_currency:currency,candidate_roc:candidateRoc,review_flags:uniqueFlags,
    balance_sheet_candidate_review:balanceSheetCandidateReview,
    enterprise_value_candidate_review:enterpriseValueCandidateReview,
    overall_status:"review_required",production_write:false
  };
}


type MfiPreviewRow = {
  symbol:string; company_name:string|null; market_cap:number|null; provider_status:string; reporting_currency:string|null;
  ebit_candidate:number|null; invested_capital_candidate:number|null; ebit_status:string;
  invested_capital_status:string; enterprise_value_candidate_review:any; balance_sheet_candidate_review:any; review_flags:string[];
};
function buildMfiRankingPreview(rows:MfiPreviewRow[]) {
  const evaluated=rows.map(row=>{
    const ev=row.market_cap!==null && row.market_cap>0
      && typeof row.enterprise_value_candidate_review?.conventional_gross_debt_candidate==="number"
      && row.enterprise_value_candidate_review.conventional_gross_debt_candidate>=0
      && typeof row.enterprise_value_candidate_review?.unrestricted_cash_candidate==="number"
      && row.enterprise_value_candidate_review.unrestricted_cash_candidate>=0
      ? row.market_cap+row.enterprise_value_candidate_review.conventional_gross_debt_candidate-row.enterprise_value_candidate_review.unrestricted_cash_candidate
      : null;
    const exclusionReasons:string[]=[];
    if(row.provider_status!=="supported") {
      exclusionReasons.push(row.provider_status==="unsupported_provider"
        ?"EdgarTools provider unsupported for this issuer"
        :"Annual filing evidence unavailable");
    } else {
      if(row.ebit_status!=="direct_reported_candidate_review_only") exclusionReasons.push("Direct reported consolidated EBIT required; filing-specific reconstructions remain manual-review-only");
      if(row.invested_capital_status!=="positive_denominator_candidate_review_only") exclusionReasons.push("Invested-capital denominator unresolved or non-positive");
      if(row.review_flags.includes("invested_capital_negative_working_capital_offset_high_risk_manual_review")) exclusionReasons.push("Near-zero / negative-working-capital offset risk requires manual review; ROC and ranking withheld");
      // ROU assets and lease liabilities are explicitly outside the proposed baseline
      // invested-capital / conventional-debt inputs. Their presence is disclosed for review,
      // but is not itself an ambiguous input or a hard shadow-ranking blocker.
      const policyScopeFlags = [
        "restricted_or_combined_cash_present_review_enterprise_value_cash_input",
        "unrestricted_cash_not_uniquely_identified",
        "restricted_cash_or_short_term_investments_require_cash_scope_review",
        "noncontrolling_interest_present_review_enterprise_value_scope",
        "noncontrolling_interest_requires_enterprise_value_adjustment_review",
        "company_perimeter_mismatch_requires_manual_review",
        "nondebt_financing_obligation_requires_enterprise_value_scope_review",
        "separate_financing_obligation_requires_enterprise_value_policy_decision"
      ];
      if(policyScopeFlags.some(flag=>row.review_flags.includes(flag))) exclusionReasons.push("Unresolved lease, cash, NCI or financing scope requires cohort-policy approval before ranking");
      if(row.reporting_currency!=="USD") exclusionReasons.push("Reporting currency not confirmed as USD");
      if(row.enterprise_value_candidate_review?.conventional_debt_status!=="identified_from_unique_current_and_noncurrent_components") exclusionReasons.push("Conventional debt inputs incomplete or ambiguous");
      const aggregateDebtCount=row.balance_sheet_candidate_review?.aggregate_debt?.candidate_count??0;
      if(aggregateDebtCount>0 && row.enterprise_value_candidate_review?.debt_reconciliation_status!=="reconciles_within_1") exclusionReasons.push("Aggregate debt does not reconcile to unique current and noncurrent components");
      if(ev===null || ev<=0) exclusionReasons.push("Enterprise-value candidate unavailable or non-positive");
      if(typeof row.ebit_candidate!=="number" || !Number.isFinite(row.ebit_candidate) || row.ebit_candidate<=0) exclusionReasons.push("EBIT candidate missing or non-positive");
      if(typeof row.invested_capital_candidate!=="number" || !Number.isFinite(row.invested_capital_candidate) || row.invested_capital_candidate<=0) exclusionReasons.push("Invested capital missing or non-positive");
    }
    const eligible=exclusionReasons.length===0;
    const eligibilityStatus=eligible?"eligible":row.provider_status==="unsupported_provider"
      ?"excluded_provider_unsupported":row.provider_status!=="supported"
      ?"excluded_filing_evidence_unavailable":"excluded_accounting_or_valuation_review";
    return {...row,enterprise_value_candidate:ev,
      earnings_yield:eligible?row.ebit_candidate!/ev!:null,
      return_on_capital:eligible?row.ebit_candidate!/row.invested_capital_candidate!:null,
      ranking_eligible:eligible,eligibility_status:eligibilityStatus,exclusion_reasons:exclusionReasons};
  });
  const eligible=evaluated.filter(row=>row.ranking_eligible);
  const minimumCohort=MINIMUM_ELIGIBLE_COHORT;
  assignCombinedRanks(eligible as any[],minimumCohort);
  const ranked=new Set(eligible.length>=minimumCohort?eligible.map(row=>row.symbol):[]);
  for(const row of evaluated as any[]) {
    if(!ranked.has(row.symbol)) {
      row.earnings_yield_rank=null; row.return_on_capital_rank=null;
      row.magic_formula_score=null; row.magic_formula_rank=null;
    }
    row.production_approved=false;
    row.production_write=false;
  }
  return {
    methodology:"Classic Greenblatt Magic Formula ordinal rank sum",
    formulas:{earnings_yield:"EBIT / (market_cap + conventional_gross_debt - unrestricted_cash)",return_on_capital:"EBIT / invested_capital",combined_score:"EY ordinal rank + ROC ordinal rank"},
    ranking_direction:"Higher earnings yield and higher return on capital receive lower (better) ordinal ranks; exact metric ties share average occupied ranks; lower combined rank sum is better. Exact combined-score ties share competition rank.",
    minimum_eligible_cohort:minimumCohort,
    summary:{
      universe:evaluated.length,eligible:eligible.length,ranked:ranked.size,excluded:evaluated.length-ranked.size,
      unsupported_provider:evaluated.filter(row=>row.eligibility_status==="excluded_provider_unsupported").length,
      filing_evidence_unavailable:evaluated.filter(row=>row.eligibility_status==="excluded_filing_evidence_unavailable").length,
      accounting_or_valuation_review:evaluated.filter(row=>row.eligibility_status==="excluded_accounting_or_valuation_review").length
    },
    methodology_version:"classic_mfi_ordinal_rank_sum_v1",
    rankings:evaluated.sort((a:any,b:any)=>a.magic_formula_rank==null?(b.magic_formula_rank==null?a.symbol.localeCompare(b.symbol):1):b.magic_formula_rank==null?-1:a.magic_formula_rank-b.magic_formula_rank || a.symbol.localeCompare(b.symbol)),
    production_fundamentals_changed:false,rankings_changed:false,production_write:false,
    guardrail:"Shadow preview only. Candidate accounting inputs are not policy-approved. Unsupported providers remain visible in coverage and are excluded from the ranked subset. No production fundamentals, ratios, eligibility or rankings are written."
  };
}

async function syncUsFundamentals(env:Env, limit=10) {
  await ensureSchema(env);
  const mapAge=await env.DB.prepare("SELECT MIN(cm.updated_at) AS updated_at,COUNT(cm.symbol) AS count FROM stock_master m LEFT JOIN sec_company_map cm ON cm.symbol=m.symbol WHERE m.market='US' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)").first<any>();
  const missingMap=await env.DB.prepare("SELECT COUNT(*) AS count FROM stock_master m LEFT JOIN sec_company_map cm ON cm.symbol=m.symbol WHERE m.market='US' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1) AND cm.symbol IS NULL").first<any>();
  const mapStale=!mapAge?.count || !mapAge.updated_at || Date.now()-Date.parse(mapAge.updated_at)>7*86400000 || (missingMap?.count??0)>0;
  if (mapStale) {
    const response=await fetch("https://www.sec.gov/files/company_tickers_exchange.json",{headers:{"User-Agent":"Magic Screen/1.0 support@binalah.co","Accept-Encoding":"gzip, deflate"}});
    if (!response.ok) throw new Error("SEC ticker map returned HTTP "+response.status);
    const payload:any=await response.json();
    const fields=payload.fields??[];
    const ix={cik:fields.indexOf("cik"),ticker:fields.indexOf("ticker")};
    if (ix.cik<0 || ix.ticker<0) throw new Error("Unexpected SEC ticker map format");
    const now=new Date().toISOString();
    const active=await env.DB.prepare("SELECT m.symbol FROM stock_master m WHERE m.market='US' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)").all<any>();
    const symbolsToMap=[...new Set(active.results.map((x:any)=>String(x.symbol).toUpperCase()))];
    const normaliseTicker=(value:string)=>value.toUpperCase().replace(/[^A-Z0-9]/g,"");
    const cikByTicker=new Map<string,string>();
    for(const row of payload.data??[]) if(Number(row[ix.cik])>0) cikByTicker.set(normaliseTicker(String(row[ix.ticker])),String(row[ix.cik]).padStart(10,"0"));
    // INTENTIONAL: SEC's 95k-row directory is an in-memory lookup only. Persist mappings
    // exclusively for the small active MFI universe; never import SEC directory companies
    // into stock_master. Upsert each MFI ticker once with its resolved CIK (or UNMAPPED),
    // avoiding the previous placeholder insert followed by a second update.
    const mappingRows=symbolsToMap.map(symbol=>({symbol,cik:cikByTicker.get(normaliseTicker(symbol))??"UNMAPPED"}));
    for(let i=0;i<mappingRows.length;i+=80) await env.DB.batch(mappingRows.slice(i,i+80).map(row=>
      env.DB.prepare("INSERT INTO sec_company_map(symbol,cik,updated_at) VALUES(?,?,?) ON CONFLICT(symbol) DO UPDATE SET cik=excluded.cik,updated_at=excluded.updated_at").bind(row.symbol,row.cik,now)
    ));
  }
  const staleCalculatedBefore=new Date(Date.now()-30*86400000).toISOString();
  const staleRetryBefore=new Date(Date.now()-7*86400000).toISOString();
  // INTENTIONAL: annual fundamentals older than 550 days are not eligible for current screening.
  // The 18-month guard catches stale XBRL tag selection while allowing normal filing-cycle delays.
  const maxAnnualPeriodAgeDays=550;
  const maxAnnualPeriodEnd=new Date(Date.now()-maxAnnualPeriodAgeDays*86400000).toISOString().slice(0,10);
  // INTENTIONAL: wait for the MFI market-cap snapshot before attempting SEC calculations.
  // This avoids recording a false incomplete result during the gap between MFI import and quote sync.
  const candidates=await env.DB.prepare("SELECT m.symbol,m.company_name,q.market_cap,cm.cik FROM stock_master m LEFT JOIN stock_snapshot q ON q.symbol=m.symbol AND q.market='US' LEFT JOIN sec_company_map cm ON cm.symbol=m.symbol LEFT JOIN stock_fundamentals f ON f.symbol=m.symbol AND f.market='US' WHERE m.market='US' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1) AND q.market_cap IS NOT NULL AND cm.cik IS NOT NULL AND cm.cik!='UNMAPPED' AND (f.updated_at IS NULL OR f.market_cap IS NOT q.market_cap OR (f.status='calculated' AND (f.updated_at<? OR f.fiscal_period<?)) OR (f.status!='calculated' AND f.updated_at<?)) ORDER BY CASE WHEN f.updated_at IS NULL THEN 0 WHEN f.status!='calculated' THEN 1 ELSE 2 END,f.updated_at,m.symbol LIMIT ?").bind(staleCalculatedBefore,maxAnnualPeriodEnd,staleRetryBefore,Math.max(1,Math.min(10,limit))).all<any>();
  let processed=0,calculated=0,stale=0,failed=0;
  for(const item of candidates.results) {
    const now=new Date().toISOString();
    try {
      const response=await fetch("https://data.sec.gov/api/xbrl/companyfacts/CIK"+item.cik+".json",{headers:{"User-Agent":"Magic Screen/1.0 support@binalah.co","Accept":"application/json"}});
      if(!response.ok) throw new Error("SEC company facts HTTP "+response.status);
      const facts:any=await response.json();
      // INTENTIONAL: anchor the fiscal period using EBIT facts or recognised annual revenue facts.
      // Some issuers do not expose operating income under standard EBIT concepts; revenue anchors
      // keep the selected period current while unsupported EBIT remains missing, never backfilled.
      const annualPeriodTags=["OperatingIncomeLoss","OperatingProfitLoss","ProfitLossFromOperatingActivities","Revenues","Revenue","RevenueFromContractWithCustomerExcludingAssessedTax","RevenueFromContractWithCustomerIncludingAssessedTax","SalesRevenueNet","SalesRevenueGoodsNet","SalesRevenueServicesNet"];
      const annualFacts=["us-gaap","ifrs-full"].flatMap(taxonomy=>annualPeriodTags.flatMap(tag=>facts?.facts?.[taxonomy]?.[tag]?.units?.USD ?? []));
      const annual=annualFacts.filter((x:any)=>x.val!=null && x.start && x.end && ["10-K","20-F","40-F"].includes(x.form) && (Date.parse(x.end)-Date.parse(x.start))/86400000>=330 && (Date.parse(x.end)-Date.parse(x.start))/86400000<=400).sort((a:any,b:any)=>b.end.localeCompare(a.end)||b.filed.localeCompare(a.filed));
      // INTENTIONAL: select one annual filing as the provenance anchor. All income-statement
      // and balance-sheet inputs below must carry this same accession number.
      const periodEnd=annual[0]?.end ?? "";
      const periodAccession=annual[0]?.accn ?? "";
      const periodAgeDays=periodEnd ? (Date.now()-Date.parse(periodEnd+"T00:00:00Z"))/86400000 : null;
      // INTENTIONAL: keep old SEC facts for diagnostics, but never calculate or rank them as current fundamentals.
      const staleFiscalPeriod=periodAgeDays!=null && periodAgeDays>maxAnnualPeriodAgeDays;
      // INTENTIONAL: accept directly reported operating income only. Do not backsolve EBIT from
      // pretax income plus interest because non-operating gains/losses can also be present.
      const ebit=periodEnd ? secFactValue(facts,["OperatingIncomeLoss","OperatingProfitLoss","ProfitLossFromOperatingActivities"],periodEnd,periodAccession,true) : {value:null,tag:null,filed:null};
      const assets=periodEnd ? secFactValue(facts,["AssetsCurrent","CurrentAssets"],periodEnd,periodAccession,false) : {value:null,tag:null,filed:null};
      const liabilities=periodEnd ? secFactValue(facts,["LiabilitiesCurrent","CurrentLiabilities"],periodEnd,periodAccession,false) : {value:null,tag:null,filed:null};
      const ppe=periodEnd ? secFactValue(facts,["PropertyPlantAndEquipmentNet","PropertyPlantAndEquipment"],periodEnd,periodAccession,false) : {value:null,tag:null,filed:null};
      // INTENTIONAL: exclude combined restricted/unrestricted cash concepts from EV.
      // If unrestricted cash is not separately reported, leave the input missing rather than overstate liquidity.
      const cash=periodEnd ? secFactValue(facts,["CashAndCashEquivalentsAtCarryingValue","CashAndCashEquivalents"],periodEnd,periodAccession,false) : {value:null,tag:null,filed:null};
      const debtCurrentAggregate=periodEnd ? secFactValue(facts,["DebtCurrent"],periodEnd,periodAccession,false) : {value:null,tag:null,filed:null};
      const borrowingsCurrentAggregate=periodEnd ? secFactValue(facts,["BorrowingsCurrent"],periodEnd,periodAccession,false) : {value:null,tag:null,filed:null};
      const debtCurrent=periodEnd ? secFactValue(facts,["LongTermDebtCurrent"],periodEnd,periodAccession,false) : {value:null,tag:null,filed:null};
      const shortDebt=periodEnd ? secFactValue(facts,["ShortTermBorrowings","ShortTermDebtCurrent"],periodEnd,periodAccession,false) : {value:null,tag:null,filed:null};
      const debtLong=periodEnd ? secFactValue(facts,["LongTermDebtNoncurrent"],periodEnd,periodAccession,false) : {value:null,tag:null,filed:null};
      const longTermDebtFallback=periodEnd ? secFactValue(facts,["LongTermDebt"],periodEnd,periodAccession,false) : {value:null,tag:null,filed:null};
      const borrowingsLong=periodEnd ? secFactValue(facts,["BorrowingsNoncurrent"],periodEnd,periodAccession,false) : {value:null,tag:null,filed:null};
      const debtAndLeaseLong=periodEnd ? secFactValue(facts,["LongTermDebtAndFinanceLeaseObligationsNoncurrent","LongTermDebtAndCapitalLeaseObligationsNoncurrent"],periodEnd,periodAccession,false) : {value:null,tag:null,filed:null};
      const leaseCurrent=periodEnd ? secFactValue(facts,["LongTermDebtAndFinanceLeaseObligationsCurrent","LongTermDebtAndCapitalLeaseObligationsCurrent"],periodEnd,periodAccession,false) : {value:null,tag:null,filed:null};
      const leaseLong=debtAndLeaseLong;
      const cap=Number(item.market_cap);
      // INTENTIONAL: keep debt components within matching accounting scopes. DebtCurrent includes
      // current maturities and capital-lease obligations, so pair it only with non-current debt+lease.
      // IFRS BorrowingsCurrent pairs with BorrowingsNoncurrent. The split US-GAAP fallback uses
      // debt-only current and non-current tags. Never mix lease-inclusive and debt-only components.
      const usAggregateDebtKnown=debtCurrentAggregate.value!=null && debtAndLeaseLong.value!=null;
      const ifrsAggregateDebtKnown=borrowingsCurrentAggregate.value!=null && borrowingsLong.value!=null;
      const splitDebtKnown=debtCurrent.value!=null && shortDebt.value!=null && debtLong.value!=null;
      // INTENTIONAL: LongTermDebt alone is not assumed to be a complete non-current split.
      // Use it only when the same filing explicitly reports aggregate current debt as zero.
      // This avoids adding a current portion twice while supporting balance sheets such as Adobe's.
      const zeroCurrentLongTermDebtKnown=debtCurrentAggregate.value===0 && longTermDebtFallback.value!=null;
      const anyBorrowingFacts=debtCurrentAggregate.value!=null || borrowingsCurrentAggregate.value!=null || debtCurrent.value!=null || shortDebt.value!=null || debtLong.value!=null || borrowingsLong.value!=null || longTermDebtFallback.value!=null;
      const leaseDebtKnown=leaseCurrent.value!=null && leaseLong.value!=null;
      const debtKnown=usAggregateDebtKnown || ifrsAggregateDebtKnown || splitDebtKnown || zeroCurrentLongTermDebtKnown || (!anyBorrowingFacts && leaseDebtKnown);
      const totalDebt=usAggregateDebtKnown ? debtCurrentAggregate.value!+debtAndLeaseLong.value!
        : ifrsAggregateDebtKnown ? borrowingsCurrentAggregate.value!+borrowingsLong.value!
        : splitDebtKnown ? debtCurrent.value!+shortDebt.value!+debtLong.value!
        : zeroCurrentLongTermDebtKnown ? longTermDebtFallback.value!
        : !anyBorrowingFacts && leaseDebtKnown ? leaseCurrent.value!+leaseLong.value! : null;
      const netWorkingCapital=assets.value!=null&&liabilities.value!=null ? assets.value-liabilities.value : null;
      const investedCapital=netWorkingCapital!=null&&ppe.value!=null ? netWorkingCapital+ppe.value : null;
      const enterpriseValue=totalDebt!=null ? cap+totalDebt-(cash.value??0) : null;
      // INTENTIONAL: a non-positive invested-capital denominator is an explicit review
      // state, not a zero ROC and not a generic missing-facts state. Do not rank it.
      const negativeInvestedCapital=investedCapital!=null&&investedCapital<0;
      const zeroInvestedCapital=investedCapital===0;
      const complete=!staleFiscalPeriod && ebit.value!=null && assets.value!=null && liabilities.value!=null && ppe.value!=null && cash.value!=null && debtKnown && totalDebt!=null && item.market_cap!=null && enterpriseValue!=null && enterpriseValue>0 && investedCapital!=null && investedCapital>0;
      const ey=complete ? (ebit.value as number)/enterpriseValue! : null;
      const roc=complete ? (ebit.value as number)/investedCapital! : null;
      const status=staleFiscalPeriod ? "stale_fiscal_period" : negativeInvestedCapital ? "negative_invested_capital" : zeroInvestedCapital ? "zero_invested_capital" : complete ? "calculated" : "missing_required_facts";
      await env.DB.prepare("INSERT INTO stock_fundamentals(symbol,market,cik,ebit,current_assets,current_liabilities,net_ppe,total_debt,cash,market_cap,earnings_yield,return_on_capital,fiscal_period,filed_at,status,source,updated_at) VALUES(?,'US',?,?,?,?,?,?,?,?,?,?,?,?,?,'SEC EDGAR Company Facts',?) ON CONFLICT(symbol,market) DO UPDATE SET cik=excluded.cik,ebit=excluded.ebit,current_assets=excluded.current_assets,current_liabilities=excluded.current_liabilities,net_ppe=excluded.net_ppe,total_debt=excluded.total_debt,cash=excluded.cash,market_cap=excluded.market_cap,earnings_yield=excluded.earnings_yield,return_on_capital=excluded.return_on_capital,fiscal_period=excluded.fiscal_period,filed_at=excluded.filed_at,status=excluded.status,source=excluded.source,updated_at=excluded.updated_at")
        .bind(item.symbol,item.cik,ebit.value,assets.value,liabilities.value,ppe.value,totalDebt,cash.value,item.market_cap,ey,roc,periodEnd||null,ebit.filed,status,now).run();
      await env.DB.prepare("UPDATE stock_snapshot SET earnings_yield=?,return_on_capital=?,magic_formula_rank=NULL,data_status=? WHERE symbol=? AND market='US'").bind(ey,roc,staleFiscalPeriod?"fundamentals_stale":negativeInvestedCapital?"fundamentals_negative_invested_capital":zeroInvestedCapital?"fundamentals_zero_invested_capital":complete?"fundamentals_calculated":"fundamentals_incomplete",item.symbol).run();
      if(complete) calculated++;
      if(staleFiscalPeriod) stale++;
      processed++;
    } catch(error) {
      failed++;
      await env.DB.prepare("INSERT INTO stock_fundamentals(symbol,market,cik,status,source,updated_at) VALUES(?,'US',?,'provider_error','SEC EDGAR Company Facts',?) ON CONFLICT(symbol,market) DO UPDATE SET status='provider_error',updated_at=excluded.updated_at").bind(item.symbol,item.cik,now).run();
      processed++;
    }
  }
  const totals=await env.DB.prepare("SELECT COUNT(*) AS total,SUM(CASE WHEN f.status='calculated' AND f.market_cap IS q.market_cap THEN 1 ELSE 0 END) AS valid FROM stock_master m LEFT JOIN stock_fundamentals f ON f.symbol=m.symbol AND f.market='US' LEFT JOIN stock_snapshot q ON q.symbol=m.symbol AND q.market='US' WHERE m.market='US' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)").first<any>();
  let ranked=0;
  // INTENTIONAL: never publish a partial-universe Magic Formula rank. Every active MFI
  // candidate must have complete, usable inputs or all ranks remain blank.
  if(totals?.total>0 && totals.valid===totals.total) {
    const unranked=await env.DB.prepare("SELECT COUNT(*) AS count FROM stock_master m LEFT JOIN stock_snapshot q ON q.symbol=m.symbol AND q.market='US' WHERE m.market='US' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1) AND q.magic_formula_rank IS NULL").first<any>();
    // INTENTIONAL: recompute only when at least one active candidate is unranked. This
    // handles a changed MFI universe even on a run that processes no new SEC facts.
    if((unranked?.count??0)>0) {
      // INTENTIONAL: equal EY or ROC values share the same component rank. RANK() avoids
      // arbitrary row-number differences between financially tied candidates.
      const rankedRows=await env.DB.prepare("SELECT f.symbol,RANK() OVER(ORDER BY f.earnings_yield DESC)+RANK() OVER(ORDER BY f.return_on_capital DESC) AS combined_rank FROM stock_fundamentals f INNER JOIN stock_master m ON m.symbol=f.symbol AND m.market=f.market WHERE f.market='US' AND f.status='calculated' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)").all<any>();
      // INTENTIONAL: only write rank rows when the calculated rank actually changes.
      // The SEC cron runs every thirty minutes; unchanged ranks do not consume D1 writes.
      for(const row of rankedRows.results) await env.DB.prepare("UPDATE stock_snapshot SET magic_formula_rank=? WHERE symbol=? AND market='US' AND magic_formula_rank IS NOT ?").bind(row.combined_rank,row.symbol,row.combined_rank).run();
      ranked=rankedRows.results.length;
    }
  } else if(processed>0 && totals?.total>0) {
    // INTENTIONAL: if any active candidate becomes incomplete, clear every rank so the
    // UI never displays a stale partial ranking as if the full universe were ranked.
    await env.DB.prepare("UPDATE stock_snapshot SET magic_formula_rank=NULL WHERE market='US' AND magic_formula_rank IS NOT NULL AND symbol IN (SELECT m.symbol FROM stock_master m WHERE m.market='US' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1))").run();
  }
  const remaining=Math.max(0,(totals?.total??0)-(totals?.valid??0));
  return {source:"SEC EDGAR Company Facts",processed,calculated,stale,failed,remaining,ranked,total:totals?.total??0,note:"Ranks are published only when every active MFI candidate has usable required facts."};
}

async function syncMagicFormulaUniverse(env: Env, minimumMarketCap=50, select30=true, forceRefresh=false) {
  await ensureSchema(env);
  await env.DB.prepare("CREATE TABLE IF NOT EXISTS mfi_screening_meta (id INTEGER PRIMARY KEY CHECK(id=1), minimum_market_cap INTEGER NOT NULL, selected_count INTEGER NOT NULL, result_count INTEGER NOT NULL, source_updated_at TEXT NOT NULL, price_date TEXT, quarter_date TEXT)").run();

  // Reuse the last successful MFI result for six hours when the screen settings match.
  // This avoids a login/session round-trip every time someone opens the screener.
  // INTENTIONAL: cache successful MFI sessions for six hours; normal page loads should
  // not repeatedly scrape the authenticated site. The explicit refresh path can bypass this.
  if (!forceRefresh) {
    const cached = await env.DB.prepare("SELECT minimum_market_cap,selected_count,result_count,source_updated_at,price_date,quarter_date FROM mfi_screening_meta WHERE id=1").first<any>();
    const cacheAge = cached?.source_updated_at ? Date.now() - Date.parse(cached.source_updated_at) : Infinity;
    if (cached && cached.minimum_market_cap === minimumMarketCap && cached.selected_count === (select30 ? 30 : 50) && cacheAge >= 0 && cacheAge < 6 * 60 * 60 * 1000) {
      const result = await env.DB.prepare("SELECT m.symbol,m.company_name AS name,COALESCE(q.market_cap,0)/1000000.0 AS marketCapMillions FROM stock_master m LEFT JOIN stock_snapshot q ON q.symbol=m.symbol AND q.market='US' WHERE m.market='US' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.source='Magic Formula Investing' AND um.active=1) ORDER BY m.company_name").all<any>();
      if (result.results.length === cached.result_count) {
        return {imported:result.results.length,minimumMarketCap,selectedCount:select30?30:50,source:"Magic Formula Investing",asOf:cached.source_updated_at,priceDate:cached.price_date,quarterDate:cached.quarter_date,cached:true,stocks:result.results};
      }
    }
  }

  if (!env.MFI_SESSION_COOKIE) throw new Error("Magic Formula session is not configured. Add MFI_SESSION_COOKIE as a Cloudflare Worker secret.");
  const headers = { "User-Agent":"Mozilla/5.0 (compatible; MagicScreen/1.0)", "Cookie":env.MFI_SESSION_COOKIE };
  const pageUrl = "https://www.magicformulainvesting.com/Screening/StockScreening";
  const page = await fetch(pageUrl, {headers, redirect:"follow"});
  const pageHtml = await page.text();
  if (!page.ok) throw new Error("Magic Formula page returned HTTP "+page.status);
  if (/Account\/LogOn|name=["']Email["']|>\s*Login\s*</i.test(page.url+" "+pageHtml)) throw new Error("Magic Formula session expired or is not authenticated. Refresh MFI_SESSION_COOKIE.");
  const token = pageHtml.match(/name=["']__RequestVerificationToken["'][^>]*value=["']([^"']+)["']/i)?.[1]
    ?? pageHtml.match(/value=["']([^"']+)["'][^>]*name=["']__RequestVerificationToken["']/i)?.[1];
  if (!token) throw new Error("Could not find the anti-forgery token. The screening page may have changed.");
  const form = new URLSearchParams();
  form.set("MinimumMarketCap",String(minimumMarketCap));
  form.set("Select30",select30?"true":"false");
  form.set("stocks","Get Stocks");
  form.set("__RequestVerificationToken",token);
  const response = await fetch(pageUrl,{method:"POST",headers:{...headers,"Accept":"*/*","Content-Type":"application/x-www-form-urlencoded; charset=UTF-8","X-Requested-With":"XMLHttpRequest","Referer":pageUrl,"Origin":"https://www.magicformulainvesting.com"},body:form.toString(),redirect:"follow"});
  const html = await response.text();
  if (!response.ok) throw new Error("Magic Formula screening returned HTTP "+response.status);
  if (/Account\/LogOn|name=["']Email["']|>\s*Login\s*</i.test(response.url+" "+html)) throw new Error("Magic Formula rejected the session. Refresh MFI_SESSION_COOKIE.");
  const table = html.match(/<table\b[^>]*class=["'][^"']*screeningdata[^"']*["'][^>]*>([\s\S]*?)<\/table>/i)?.[1];
  if (!table) throw new Error("Could not find the screening results table in Magic Formula response.");
  // INTENTIONAL: the provider's screening table is alphabetically sorted and does not
  // contain EY/ROC ranks. Preserve it as a candidate universe, never as a ranking order.
  const rows = [...table.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)].map(match => {
    const cells = [...match[1].matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map(cell =>
      cell[1].replace(/<[^>]*>/g," ").replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/&quot;/gi,'"').replace(/&#39;|&apos;/gi,"'").replace(/\s+/g," ").trim()
    );
    if (cells.length < 5) return null;
    const symbol = cells[1].toUpperCase().replace(/[^A-Z0-9.\-]/g,"");
    const cap = Number(cells[2].replace(/,/g,""));
    if (!symbol || !Number.isFinite(cap)) return null;
    return {symbol,name:cells[0],marketCapMillions:cap,priceDate:cells[3],quarterDate:cells[4]};
  }).filter((row): row is {symbol:string;name:string;marketCapMillions:number;priceDate:string;quarterDate:string} => !!row && !!row.name);
  if (!rows.length) throw new Error("Magic Formula returned no parseable stock rows.");
  const now = new Date().toISOString();
  const previousUniverse = await env.DB.prepare("SELECT m.symbol,q.market_cap FROM stock_master m LEFT JOIN stock_snapshot q ON q.symbol=m.symbol AND q.market='US' WHERE m.market='US' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1) ORDER BY m.symbol").all<any>();
  const previousCaps = new Map<string,number|null>(previousUniverse.results.map((row:any)=>[String(row.symbol),row.market_cap==null?null:Number(row.market_cap)]));
  const previousSymbols = previousUniverse.results.map((row:any)=>String(row.symbol)).sort();
  const nextSymbols = rows.map(row=>row.symbol).sort();
  const universeChanged = previousSymbols.length!==nextSymbols.length || previousSymbols.some((symbol:string,index:number)=>symbol!==nextSymbols[index]);
  const marketCapChanged = rows.some(row=>previousCaps.has(row.symbol) && previousCaps.get(row.symbol)!==row.marketCapMillions*1000000);
  // INTENTIONAL: MFI.com is one source of US universe membership. A refresh may only change the
  // MFI membership; frontend memberships are never deactivated here (see worker/universe-membership.mjs).
  const applied=await applyMfiSelection(env.DB,rows,now);
  if(universeChanged || marketCapChanged || applied.unionChanged) {
    // INTENTIONAL: candidate membership or market-cap changes invalidate the previous
    // combined ranking. SEC ingestion republishes ranks only after all inputs are current.
    await invalidateUsRanks(env.DB);
  }
  await env.DB.prepare("INSERT INTO mfi_screening_meta (id,minimum_market_cap,selected_count,result_count,source_updated_at,price_date,quarter_date) VALUES (1,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET minimum_market_cap=excluded.minimum_market_cap,selected_count=excluded.selected_count,result_count=excluded.result_count,source_updated_at=excluded.source_updated_at,price_date=excluded.price_date,quarter_date=excluded.quarter_date").bind(minimumMarketCap,select30?30:50,rows.length,now,rows[0]?.priceDate ?? null,rows[0]?.quarterDate ?? null).run();
  return {imported:rows.length,minimumMarketCap,selectedCount:select30?30:50,source:"Magic Formula Investing",asOf:now,priceDate:rows[0]?.priceDate ?? null,quarterDate:rows[0]?.quarterDate ?? null,cached:false,stocks:rows,membership:{mfiAdded:applied.mfiAdded,mfiDeactivated:applied.mfiDeactivated,stillActiveViaOtherSource:applied.stillActiveViaOtherSource,activeUniverseSize:applied.activeUniverseSize}};
}

async function diagnoseSecExtensionFacts(env:Env,symbol:string) {
  const stock=await env.DB.prepare("SELECT m.symbol,m.company_name,cm.cik FROM stock_master m JOIN sec_company_map cm ON cm.symbol=m.symbol WHERE m.market='US' AND m.symbol=? AND m.listing_status='active' AND cm.cik!='UNMAPPED'").bind(symbol).first<any>();
  if(!stock) throw new Error("Active MFI ticker or SEC CIK mapping not found");
  const headers={"User-Agent":"Magic Screen/1.0 support@binalah.co","Accept":"application/json,application/xml,text/xml"};
  const factsResponse=await fetch("https://data.sec.gov/api/xbrl/companyfacts/CIK"+stock.cik+".json",{headers});
  if(!factsResponse.ok) throw new Error("SEC Company Facts HTTP "+factsResponse.status);
  const facts:any=await factsResponse.json();
  const anchorTags=["OperatingIncomeLoss","OperatingProfitLoss","ProfitLossFromOperatingActivities","Revenues","Revenue","RevenueFromContractWithCustomerExcludingAssessedTax","RevenueFromContractWithCustomerIncludingAssessedTax","SalesRevenueNet"];
  const annual=["us-gaap","ifrs-full"].flatMap(t=>anchorTags.flatMap(tag=>facts?.facts?.[t]?.[tag]?.units?.USD??[])).filter((x:any)=>x.val!=null&&x.start&&x.end&&["10-K","20-F","40-F"].includes(x.form)&&(Date.parse(x.end)-Date.parse(x.start))/86400000>=330&&(Date.parse(x.end)-Date.parse(x.start))/86400000<=400).sort((a:any,b:any)=>b.end.localeCompare(a.end)||b.filed.localeCompare(a.filed));
  const anchor=annual[0];
  if(!anchor?.accn) throw new Error("No annual USD filing anchor found in standard SEC Company Facts");
  const base="https://www.sec.gov/Archives/edgar/data/"+String(Number(stock.cik))+"/"+anchor.accn.replace(/-/g,"")+"/";
  const indexResponse=await fetch(base+"index.json",{headers});
  if(!indexResponse.ok) throw new Error("SEC filing index HTTP "+indexResponse.status);
  const index:any=await indexResponse.json();
  const files=index?.directory?.item??[];
  const instance=files.find((x:any)=>/_htm\.xml$/i.test(String(x.name??"")))??files.find((x:any)=>/extracted xbrl instance document/i.test(String(x.description??"")));
  if(!instance?.name) throw new Error("SEC extracted XBRL instance not found");
  const instanceResponse=await fetch(base+encodeURIComponent(instance.name),{headers});
  if(!instanceResponse.ok) throw new Error("SEC XBRL instance HTTP "+instanceResponse.status);
  const xml=await instanceResponse.text();
  const contexts=new Map<string,{start:string|null;end:string;dimensions:boolean}>();
  for(const m of xml.matchAll(/<(?:[A-Za-z0-9_-]+:)?context\b([^>]*)>([\s\S]*?)<\/(?:[A-Za-z0-9_-]+:)?context>/gi)){
    const id=m[1].match(/\bid=["']([^"']+)["']/i)?.[1],body=m[2];
    const start=body.match(/<(?:[A-Za-z0-9_-]+:)?startDate>([^<]+)</i)?.[1]??null;
    const end=body.match(/<(?:[A-Za-z0-9_-]+:)?endDate>([^<]+)</i)?.[1]??body.match(/<(?:[A-Za-z0-9_-]+:)?instant>([^<]+)</i)?.[1];
    if(id&&end) contexts.set(id,{start,end,dimensions:/<(?:[A-Za-z0-9_-]+:)?(?:explicitMember|typedMember)\b/i.test(body)});
  }
  const units=new Map<string,string>();
  for(const m of xml.matchAll(/<(?:[A-Za-z0-9_-]+:)?unit\b([^>]*)>([\s\S]*?)<\/(?:[A-Za-z0-9_-]+:)?unit>/gi)){
    const id=m[1].match(/\bid=["']([^"']+)["']/i)?.[1];
    const measure=m[2].replace(/<[^>]*>/g,"").trim();
    if(id) units.set(id,measure);
  }
  const labelFile=files.find((x:any)=>String(x.name??"").toLowerCase().endsWith("_lab.xml"));
  const labels=new Map<string,string>();
  let labelStatus="not_found";
  if(labelFile?.name){
    const lr=await fetch(base+encodeURIComponent(labelFile.name),{headers});
    if(lr.ok){
      labelStatus="loaded";
      const labelXml=await lr.text();
      for(const link of labelXml.matchAll(/<(?:[A-Za-z0-9_-]+:)?labelLink\b[^>]*>([\s\S]*?)<\/(?:[A-Za-z0-9_-]+:)?labelLink>/gi)){
        const body=link[1],locators=new Map<string,string>(),resources=new Map<string,string>();
        for(const m of body.matchAll(/<(?:[A-Za-z0-9_-]+:)?loc\b([^>]*)\/?\s*>/gi)){
          const lab=m[1].match(/xlink:label=["']([^"']+)["']/i)?.[1],href=m[1].match(/xlink:href=["']([^"']+)["']/i)?.[1];
          const concept=href?.split("#").pop(); if(lab&&concept) locators.set(lab,concept);
        }
        for(const m of body.matchAll(/<(?:[A-Za-z0-9_-]+:)?label\b([^>]*)>([\s\S]*?)<\/(?:[A-Za-z0-9_-]+:)?label>/gi)){
          const lab=m[1].match(/xlink:label=["']([^"']+)["']/i)?.[1],value=m[2].replace(/<[^>]*>/g,"").replace(/&amp;/g,"&").trim();
          if(lab&&value) resources.set(lab,value);
        }
        for(const m of body.matchAll(/<(?:[A-Za-z0-9_-]+:)?labelArc\b([^>]*)\/?\s*>/gi)){
          const from=m[1].match(/xlink:from=["']([^"']+)["']/i)?.[1],to=m[1].match(/xlink:to=["']([^"']+)["']/i)?.[1];
          const concept=from?locators.get(from):null,label=to?resources.get(to):null;
          if(concept&&label) {
            // INTENTIONAL: XBRL linkbase locators identify extension concepts as namespace_localName
            // (for example, issuer_Revenue), while instance elements expose the local XML name
            // (Revenue). Index both forms so filing labels are not silently lost.
            if(!labels.has(concept)) labels.set(concept,label);
            const localName=concept.replace(/^[^_]+_/,"");
            if(localName!==concept&&!labels.has(localName)) labels.set(localName,label);
          }
        }
      }
    } else labelStatus="http_"+lr.status;
  }
  const presentationFile=files.find((x:any)=>String(x.name??"").toLowerCase().endsWith("_pre.xml"));
  const presentationByConcept=new Map<string,any[]>();
  let presentationStatus="not_found";
  if(presentationFile?.name){
    const pr=await fetch(base+encodeURIComponent(presentationFile.name),{headers});
    if(pr.ok){
      presentationStatus="loaded";
      const presentationXml=await pr.text();
      for(const link of presentationXml.matchAll(/<(?:[A-Za-z0-9_-]+:)?presentationLink\b([^>]*)>([\s\S]*?)<\/(?:[A-Za-z0-9_-]+:)?presentationLink>/gi)){
        const linkAttrs=link[1],body=link[2];
        const role=linkAttrs.match(/xlink:role=["']([^"']+)["']/i)?.[1]??null;
        const locators=new Map<string,string>();
        for(const loc of body.matchAll(/<(?:[A-Za-z0-9_-]+:)?loc\b([^>]*)\/?\s*>/gi)){
          const attrs=loc[1],label=attrs.match(/xlink:label=["']([^"']+)["']/i)?.[1],href=attrs.match(/xlink:href=["']([^"']+)["']/i)?.[1];
          const concept=href?.split("#").pop()?.replace(/^[^_]+_/,"");
          if(label&&concept) locators.set(label,concept);
        }
        for(const arc of body.matchAll(/<(?:[A-Za-z0-9_-]+:)?presentationArc\b([^>]*)\/?\s*>/gi)){
          const attrs=arc[1],from=attrs.match(/xlink:from=["']([^"']+)["']/i)?.[1],to=attrs.match(/xlink:to=["']([^"']+)["']/i)?.[1];
          const parent=from?locators.get(from):null,child=to?locators.get(to):null;
          if(!parent||!child) continue;
          const order=attrs.match(/\border=["']([^"']+)["']/i)?.[1]??null;
          const preferredLabel=attrs.match(/preferredLabel=["']([^"']+)["']/i)?.[1]??null;
          // INTENTIONAL: presentation arcs are structural evidence only. They do not establish that a fact is a complete balance or income-statement total.
          const entry={role,parent,child,order,preferred_label:preferredLabel};
          const list=presentationByConcept.get(child)??[];
          if(list.length<12) list.push(entry);
          presentationByConcept.set(child,list);
        }
      }
    } else presentationStatus="http_"+pr.status;
  }
  // INTENTIONAL: role definitions provide filing-specific presentation context.
  // SEC guidance distinguishes statement roles from note/disclosure roles; unknown
  // roles remain unclassified rather than being guessed from a fact's label.
  const schemaFile=files.find((x:any)=>String(x.name??"").toLowerCase().endsWith(".xsd"));
  const roleDefinitions=new Map<string,string>();
  let schemaStatus="not_found";
  if(schemaFile?.name){
    const sr=await fetch(base+encodeURIComponent(schemaFile.name),{headers});
    if(sr.ok){
      schemaStatus="loaded";
      const schemaXml=await sr.text();
      for(const roleType of schemaXml.matchAll(/<(?:[A-Za-z0-9_-]+:)?roleType\b([^>]*)>([\s\S]*?)<\/(?:[A-Za-z0-9_-]+:)?roleType>/gi)){
        const roleUri=roleType[1].match(/roleURI=["']([^"']+)["']/i)?.[1];
        const definition=roleType[2].match(/<(?:[A-Za-z0-9_-]+:)?definition\b[^>]*>([\s\S]*?)<\/(?:[A-Za-z0-9_-]+:)?definition>/i)?.[1]?.replace(/<[^>]*>/g,"").replace(/&amp;/g,"&").trim();
        if(roleUri&&definition) roleDefinitions.set(roleUri,definition);
      }
    } else schemaStatus="http_"+sr.status;
  }
  const classifyPresentation=(role:string|null)=>{
    const definition=role?roleDefinitions.get(role)??"": "";
    const normalized=(role+" "+definition).toLowerCase().replace(/[^a-z0-9]+/g,"");
    if(/segment|disclosure|notes?tofinancialstatements|supplementaryinformation/.test(normalized)) return "disclosure_or_segment";
    if(/consolidated.*statement|statement.*consolidated/.test(normalized)) return "consolidated_statement";
    if(/statement/.test(normalized)) return "statement_role";
    return "unclassified";
  };
  const candidates:any[]=[];
  const statementCandidates:any[]=[];
  const relevant=/(revenue|sales|operating|expense|cost|income|debt|borrow|cash|property|plant|asset|liabilit|lease|capital|receivable|payable|inventory|goodwill|depreciation|amortization|tax|interest|profit|loss)/i;
  const standardPrefixes=new Set(["us-gaap","ifrs-full"]);
  const excludedPrefixes=new Set(["us-gaap","ifrs-full","dei","srt","ecd","country","currency","stpr","exch"]);
  for(const m of xml.matchAll(/<([A-Za-z][\w.-]*):([A-Za-z][\w.-]*)\b([^>]*)>([\s\S]*?)<\/\1:\2>/g)){
    const prefix=m[1],tag=m[2],attrs=m[3],raw=m[4];
    const isStandard=standardPrefixes.has(prefix.toLowerCase());
    if((excludedPrefixes.has(prefix.toLowerCase())&&!isStandard)||!relevant.test(tag)) continue;
    const contextId=attrs.match(/\bcontextRef=["']([^"']+)["']/i)?.[1],unitId=attrs.match(/\bunitRef=["']([^"']+)["']/i)?.[1];
    const context=contextId?contexts.get(contextId):null;
    if(!context||context.end!==anchor.end) continue;
    // INTENTIONAL: expose only instant facts and full-year duration facts for this filing period.
    // Same end date alone can also match quarterly durations and would blur annual context.
    if(context.start){
      const days=(Date.parse(context.end)-Date.parse(context.start))/86400000;
      if(days<330||days>400) continue;
    }
    const valueText=raw.replace(/<[^>]*>/g,"").replace(/&amp;/g,"&").trim();
    if(!/^-?\d+(?:\.\d+)?$/.test(valueText)) continue;
    const scale=Number(attrs.match(/\bscale=["'](-?\d+)["']/i)?.[1]??0),sign=attrs.match(/\bsign=["']([^"']+)["']/i)?.[1]==="-"?-1:1;
    const value=Number(valueText)*Math.pow(10,scale)*sign;
    if(!Number.isFinite(value)) continue;
    const fact={tag:prefix+":"+tag,label:labels.get(tag)??null,value,start:context.start,end:context.end,kind:context.start?"duration":"instant",unit:unitId?units.get(unitId)??null:null,dimensions:context.dimensions,context:contextId,presentation:presentationByConcept.get(tag)??[]};
    if(isStandard) {
      // INTENTIONAL: standard taxonomy facts are shown beside extension facts for review, but remain diagnostic-only and are never promoted into production calculations by this endpoint.
      statementCandidates.push(fact);
    } else candidates.push(fact);
  }
  // INTENTIONAL: deduplicate facts by their complete dimensional signature. The same
  // fact can be repeated through multiple contexts or presentation roles; dimensional
  // members remain distinct only when their actual dimension members differ.
  const dedupe=(items:any[])=>{
    const seen=new Set<string>();
    return items.filter(f=>{
      const dimensionKey=f.dimensions?JSON.stringify(f.dimensions):"";
      const key=[f.tag,f.unit,f.value,f.kind,f.start??"",f.end,dimensionKey].join("|");
      if(seen.has(key)) return false;
      seen.add(key); return true;
    });
  };
  const standardUnique=dedupe(statementCandidates);
  const extensionUnique=dedupe(candidates);
  const priority=(tag:string)=>{
    const t=tag.toLowerCase().replace(/^.*:/,"");
    // INTENTIONAL: match complete accounting concepts, not loose substrings.
    // In particular, "nonoperating income" must never be mistaken for EBIT.
    if(/^(operatingincomeloss|operatingprofitloss|profitlossfromoperatingactivities|incomelossfromcontinuingoperationsbeforeinterestexpenseoperatingincome)$/.test(t)) return 1;
    if(/^(revenues|revenuefromcontractwithcustomerexcludingassessedtax|salesrevenuenet|salesrevenuegoodsnet|salesrevenueservicesnet)$/.test(t)) return 2;
    if(/(longtermdebt|shorttermdebt|debtcurrent|debtnoncurrent|borrowingscurrent|borrowingsnoncurrent|totaldebt)/.test(t)) return 3;
    if(/^(cashandcashequivalentsatcarryingvalue|cashcash equivalents|cashcash equivalentsatcarryingvalue|cashandcash equivalentsatcarryingvalue|cashandcashequivalentsincludingrestrictedcashandcashequivalents)$/.test(t)) return 4;
    if(/^(assetscurrent|liabilitiescurrent)$/.test(t)) return 5;
    if(/^(propertyplantandequipmentnet|propertyplantandequipment)$/.test(t)) return 6;
    if(/^(costsandexpenses|operatingexpenses|costofgoodsandservicessold)$/.test(t)) return 7;
    if(/^interestexpense/.test(t)) return 8;
    return 99;
  };
  // INTENTIONAL: prioritize Magic Formula input candidates, rather than alphabetical tags.
  // This makes the small response useful for reviewing EBIT, EV and invested-capital inputs.
  // INTENTIONAL: consolidated non-dimensional facts come first. Dimensional
  // breakdowns can be useful for issuer-specific research, but must not crowd out
  // company-wide inputs in this compact Magic Formula review response.
  const relevantStandard=standardUnique.filter(f=>priority(f.tag)<99&&!f.dimensions)
    .sort((a,b)=>priority(a.tag)-priority(b.tag)||a.tag.localeCompare(b.tag));
  const extensionPriority=(fact:any)=>{
    const t=String(fact.tag+" "+(fact.label??"")).toLowerCase().replace(/[^a-z0-9]+/g,"");
    // INTENTIONAL: rank extension candidates by likely Magic Formula input meaning,
    // while keeping consolidated facts ahead of dimensional breakdowns. This is
    // diagnostic ordering only; priority never approves a concept for production.
    if(/operating(income|profit)|profitlossfromoperating/.test(t)) return 1;
    if(/revenue|sales/.test(t)) return 2;
    if(/currentassets/.test(t)) return 3;
    if(/currentliabilit/.test(t)) return 4;
    if(/propertyplantandequipment|netppe|fixedassets/.test(t)) return 5;
    if(/cashandcashequivalent|cashandbank|cashbalance/.test(t)) return 6;
    if(/totaldebt|debtnoncurrent|debtcurrent|borrowings|loanspayable/.test(t)) return 7;
    if(/interestexpense|financecost/.test(t)) return 8;
    if(/operatingexpense|costofsales|costofrevenue|costsandexpenses/.test(t)) return 9;
    if(/asset|liabilit|lease|receivable|payable|inventory/.test(t)) return 10;
    return 99;
  };
  const relevantExtensions=extensionUnique
    .sort((a,b)=>Number(a.dimensions)-Number(b.dimensions)||extensionPriority(a)-extensionPriority(b)||a.tag.localeCompare(b.tag));
  const compact=(fact:any)=>({
    tag:fact.tag,label:fact.label,value:fact.value,start:fact.start??null,end:fact.end,
    unit:fact.unit,kind:fact.kind,context:fact.context??null,dimensions:fact.dimensions,
    presentation:fact.presentation.slice(0,3).map((p:any)=>({
      parent:p.parent,parent_label:labels.get(p.parent)??null,role:p.role,
      role_definition:roleDefinitions.get(p.role)??null,
      role_classification:classifyPresentation(p.role)
    }))
  });
  // INTENTIONAL: return targeted accounting candidates independently of the compact
  // top-30 extension preview. A relevant PP&E or EBIT fact must not disappear merely
  // because unrelated issuer extensions sort ahead of it. These are review candidates,
  // not approved mappings; presentation and label evidence still require human review.
  const allReviewFacts=[...standardUnique,...extensionUnique];
  const targetedPatterns:Record<string,RegExp>={
    operating_income:/(operating.?income|operating.?profit|profit.?loss.?from.?operating|income.?loss.?from.?continuing.?operations.?before.?interest|\bebit\b|earnings.?before.?interest.?and.?tax)/i,
    ppe:/(property.?plant.?and.?equipment|plant.?and.?machinery|machinery.?and.?equipment|fixed.?assets|net.?ppe|accumulated.?depreciation|depreciation.?depletion.?and.?amortization.?property)/i,
    current_assets:/(assets.?current|current.?assets)/i,
    current_liabilities:/(liabilities.?current|current.?liabilities)/i,
    cash:/(cash.?and.?cash.?equivalent|cash.?and.?bank|cash.?balance)/i,
    debt:/(long.?term.?debt|short.?term.?debt|debt.?current|debt.?noncurrent|borrowings|loans.?payable|total.?debt)/i
  };
  const targetedCandidates=Object.fromEntries(Object.entries(targetedPatterns).map(([key,pattern])=>{
    const presentationPriority=(fact:any)=>{
      const classes=(fact.presentation??[]).map((p:any)=>classifyPresentation(p.role));
      return classes.includes("consolidated_statement")?0:classes.includes("statement_role")?1:classes.includes("disclosure_or_segment")?2:3;
    };
    const matches=allReviewFacts.filter(f=>pattern.test(String(f.tag+" "+(f.label??""))))
      .sort((a,b)=>Number(a.dimensions)-Number(b.dimensions)||presentationPriority(a)-presentationPriority(b)||a.tag.localeCompare(b.tag));
    return [key,{count:matches.length,returned:Math.min(matches.length,25),truncated:matches.length>25,facts:matches.slice(0,25).map(compact)}];
  }));
  // INTENTIONAL: provide a filing-specific arithmetic lead for review when both
  // consolidated annual revenue and total costs/expenses are explicitly tagged.
  // This is NOT an EBIT mapping: issuers can classify non-operating items differently,
  // and the result must be reconciled to the primary statements before any production use.
  const reviewFact=(tag:string)=>standardUnique.find(f=>
    f.tag.toLowerCase()===("us-gaap:"+tag).toLowerCase() &&
    !f.dimensions && f.unit==="iso4217:USD" && f.kind==="duration" &&
    f.end===anchor.end &&
    f.presentation.some((p:any)=>String(p.role??"").toLowerCase().includes("consolidatedstatementsofoperations"))
  );
  const reviewRevenue=reviewFact("RevenueFromContractWithCustomerExcludingAssessedTax");
  const reviewCosts=reviewFact("CostsAndExpenses");
  const reviewDurationFact=(tags:string[])=>standardUnique.find(f=>
    tags.some(tag=>f.tag.toLowerCase()===("us-gaap:"+tag).toLowerCase()) &&
    !f.dimensions && f.unit==="iso4217:USD" && f.kind==="duration" && f.end===anchor.end
  );
  const reviewInterest=reviewDurationFact(["InterestExpenseDebt","InterestAndDebtExpense"]);
  const reviewOtherNonOperating=reviewDurationFact(["OtherNonoperatingIncomeExpense"]);
  const reviewPretax=reviewDurationFact(["IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest","IncomeLossFromContinuingOperationsBeforeIncomeTaxesMinorityInterestAndIncomeLossFromEquityMethodInvestments"]);
  // INTENTIONAL: mirror the production parser's direct operating-income concepts across
  // both supported standard taxonomies. Do not treat generic profit, pretax income, or
  // non-operating income concepts as EBIT.
  const directOperatingIncomeTags=new Set([
    "us-gaap:OperatingIncomeLoss",
    "us-gaap:OperatingProfitLoss",
    "us-gaap:ProfitLossFromOperatingActivities",
    "ifrs-full:OperatingProfitLoss",
    "ifrs-full:ProfitLossFromOperatingActivities"
  ]);
  const explicitOperatingIncomeFact=standardUnique.find(f=>
    directOperatingIncomeTags.has(f.tag) &&
    !f.dimensions && f.unit==="iso4217:USD" && f.kind==="duration" && f.end===anchor.end
  )??null;
  const explicitOperatingIncome=explicitOperatingIncomeFact!==null;
  const arithmeticEbit=reviewRevenue&&reviewCosts?reviewRevenue.value-reviewCosts.value:null;
  const reconciledPretax=arithmeticEbit!==null&&reviewInterest&&reviewOtherNonOperating
    ? arithmeticEbit-reviewInterest.value+reviewOtherNonOperating.value : null;
  const reviewOnlyChecks={
    explicit_operating_income_fact_found:explicitOperatingIncome,
    explicit_operating_income_fact:explicitOperatingIncomeFact?{
      tag:explicitOperatingIncomeFact.tag,
      label:explicitOperatingIncomeFact.label,
      value:explicitOperatingIncomeFact.value,
      unit:explicitOperatingIncomeFact.unit,
      kind:explicitOperatingIncomeFact.kind,
      presentation:explicitOperatingIncomeFact.presentation.slice(0,1).map((p:any)=>({parent:p.parent,role:p.role}))
    }:null,
    revenue_less_costs_and_expenses:reviewRevenue&&reviewCosts?{
      revenue:reviewRevenue.value,
      costs_and_expenses:reviewCosts.value,
      arithmetic_result:arithmeticEbit,
      status:"review_only_not_approved_ebit",
      note:"Arithmetic candidate only. Confirm that CostsAndExpenses represents operating expenses for this issuer and reconcile non-operating items before treating the result as EBIT."
    }:null,
    pretax_reconciliation:reconciledPretax!==null?{
      arithmetic_ebit:arithmeticEbit,
      interest_expense:reviewInterest!.value,
      other_nonoperating_income_expense:reviewOtherNonOperating!.value,
      calculated_pretax_income:reconciledPretax,
      reported_pretax_income:reviewPretax?.value??null,
      difference:reviewPretax?reconciledPretax-reviewPretax.value:null,
      status:reviewPretax&&reconciledPretax===reviewPretax.value?"exact_arithmetic_reconciliation":"requires_manual_review",
      note:"Cross-check only. Exact arithmetic reconciliation supports the issuer-specific interpretation but does not automatically approve an EBIT mapping."
    }:null
  };
  return {symbol:stock.symbol,company_name:stock.company_name,source:"SEC filing XBRL",filing:{accession:anchor.accn,period:anchor.end,form:anchor.form,filed_at:anchor.filed,url:base+"index.html"},linkbases:{labels:labelStatus,presentation:presentationStatus,schema:schemaStatus},counts:{extension:extensionUnique.length,standard:standardUnique.length,priority_standard:relevantStandard.length,role_definitions:roleDefinitions.size},extension_facts:relevantExtensions.slice(0,30).map(compact),statement_facts:relevantStandard.slice(0,24).map(compact),targeted_candidates:targetedCandidates,review_only_checks:reviewOnlyChecks,truncated:relevantExtensions.length>30||relevantStandard.length>24,eligible_for_magic_formula:false,note:"Focused diagnostic only. Presentation role classification is supporting evidence, not proof of consolidation or accounting equivalence. Unclassified roles must be reviewed in the filing. No production ratios or rankings are changed."};
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    if (url.pathname==="/api/pipeline/status" && request.method==="GET") {
      try {
        await ensureSchema(env);
        const market=url.searchParams.get("market")==="US" ? "US" : "MY";
        const quotes=await env.DB.prepare("SELECT MAX(updated_at) AS last_updated FROM stock_snapshot WHERE market=?").bind(market).first<any>();
        if (market==="MY") return json({market,last_quote_sync:quotes?.last_updated??null});
        const mfi=await env.DB.prepare("SELECT source_updated_at,price_date,quarter_date,result_count,minimum_market_cap,selected_count FROM mfi_screening_meta WHERE id=1").first<any>();
        const sec=await env.DB.prepare("SELECT COUNT(*) AS total,COALESCE(SUM(CASE WHEN f.status='calculated' AND f.market_cap IS q.market_cap THEN 1 ELSE 0 END),0) AS calculated,COALESCE(SUM(CASE WHEN f.status='calculated' AND f.market_cap IS NOT q.market_cap THEN 1 ELSE 0 END),0) AS stale_market_cap,COALESCE(SUM(CASE WHEN f.status='missing_required_facts' THEN 1 ELSE 0 END),0) AS incomplete,COALESCE(SUM(CASE WHEN f.status='negative_invested_capital' THEN 1 ELSE 0 END),0) AS negative_invested_capital,COALESCE(SUM(CASE WHEN f.status='zero_invested_capital' THEN 1 ELSE 0 END),0) AS zero_invested_capital,COALESCE(SUM(CASE WHEN f.status='stale_fiscal_period' THEN 1 ELSE 0 END),0) AS stale_fiscal_period,COALESCE(SUM(CASE WHEN f.status='provider_error' THEN 1 ELSE 0 END),0) AS provider_error,COALESCE(SUM(CASE WHEN cm.cik IS NULL OR cm.cik='UNMAPPED' THEN 1 ELSE 0 END),0) AS unmapped,COALESCE(SUM(CASE WHEN q.market_cap IS NULL THEN 1 ELSE 0 END),0) AS awaiting_market_cap,COALESCE(SUM(CASE WHEN q.market_cap IS NOT NULL AND cm.cik IS NOT NULL AND cm.cik!='UNMAPPED' AND f.status IS NULL THEN 1 ELSE 0 END),0) AS awaiting_fundamentals,MAX(f.updated_at) AS last_updated FROM stock_master m LEFT JOIN stock_fundamentals f ON f.symbol=m.symbol AND f.market='US' LEFT JOIN stock_snapshot q ON q.symbol=m.symbol AND q.market='US' LEFT JOIN sec_company_map cm ON cm.symbol=m.symbol WHERE m.market='US' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)").first<any>();
        return json({market,last_quote_sync:quotes?.last_updated??null,mfi_last_sync:mfi?.source_updated_at??null,mfi_price_date:mfi?.price_date??null,mfi_quarter_date:mfi?.quarter_date??null,mfi_count:mfi?.result_count??0,mfi_minimum_market_cap:mfi?.minimum_market_cap??null,mfi_selected_count:mfi?.selected_count??null,sec});
      } catch(e) { return json({error:e instanceof Error?e.message:String(e)},503); }
    }
    if (url.pathname==="/api/fundamentals/status" && request.method==="GET") {
      try {
        await ensureSchema(env);
        const status=await env.DB.prepare("SELECT COUNT(*) AS total,COALESCE(SUM(CASE WHEN f.status='calculated' AND f.market_cap IS q.market_cap THEN 1 ELSE 0 END),0) AS calculated,COALESCE(SUM(CASE WHEN f.status='calculated' AND f.market_cap IS NOT q.market_cap THEN 1 ELSE 0 END),0) AS stale_market_cap,COALESCE(SUM(CASE WHEN f.status='missing_required_facts' THEN 1 ELSE 0 END),0) AS incomplete,COALESCE(SUM(CASE WHEN f.status='negative_invested_capital' THEN 1 ELSE 0 END),0) AS negative_invested_capital,COALESCE(SUM(CASE WHEN f.status='zero_invested_capital' THEN 1 ELSE 0 END),0) AS zero_invested_capital,COALESCE(SUM(CASE WHEN f.status='provider_error' THEN 1 ELSE 0 END),0) AS provider_error,COALESCE(SUM(CASE WHEN cm.cik IS NULL OR cm.cik='UNMAPPED' THEN 1 ELSE 0 END),0) AS unmapped,COALESCE(SUM(CASE WHEN q.market_cap IS NULL THEN 1 ELSE 0 END),0) AS awaiting_market_cap,COALESCE(SUM(CASE WHEN q.market_cap IS NOT NULL AND cm.cik IS NOT NULL AND cm.cik!='UNMAPPED' AND f.status IS NULL THEN 1 ELSE 0 END),0) AS awaiting_fundamentals,MAX(f.updated_at) AS last_updated FROM stock_master m LEFT JOIN stock_fundamentals f ON f.symbol=m.symbol AND f.market='US' LEFT JOIN stock_snapshot q ON q.symbol=m.symbol AND q.market='US' LEFT JOIN sec_company_map cm ON cm.symbol=m.symbol WHERE m.market='US' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)").first<any>();
        return json({source:"SEC EDGAR Company Facts",...status});
      } catch(e) { return json({error:e instanceof Error?e.message:String(e)},503); }
    }
    if (url.pathname==="/api/fundamentals/sync" && request.method==="GET") {
      try {
        const limit=Math.min(10,Math.max(1,Number(url.searchParams.get("limit")??8)));
        return json(await syncUsFundamentals(env,limit));
      } catch(e) { return json({error:e instanceof Error?e.message:String(e),source:"SEC EDGAR Company Facts"},503); }
    }

    if (url.pathname==="/api/fundamentals/edgartools/universe" && request.method==="GET") {
      if (!env.UNIVERSE_SYNC_TOKEN) return json({error:"UNIVERSE_SYNC_TOKEN is not configured"},503);
      if (request.headers.get("Authorization") !== "Bearer " + env.UNIVERSE_SYNC_TOKEN) return json({error:"Unauthorized"},401);
      try {
        await ensureSchema(env);
        // INTENTIONAL: refresh the active MFI candidate list at most once per six hours.
        // This lets the daily EdgarTools job discover newly screened stocks without
        // requiring someone to open the screener first. Existing universe-change
        // invalidation rules remain owned by syncMagicFormulaUniverse.
        const universeSync=await syncMagicFormulaUniverse(env,50,true,false);
        const rows=await env.DB.prepare("SELECT m.symbol,m.company_name,q.market_cap FROM stock_master m LEFT JOIN stock_snapshot q ON q.symbol=m.symbol AND q.market='US' WHERE m.market='US' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1) ORDER BY m.symbol").all<any>();
        return json({primary_provider:"EdgarTools",market:"US",source:"active Magic Formula Investing stock_master",count:rows.results.length,symbols:rows.results.map((row:any)=>row.symbol),stocks:rows.results,selection:{minimum_market_cap_millions:universeSync.minimumMarketCap,selected_count:universeSync.selectedCount},universe_refresh:{cached:universeSync.cached??false,imported:universeSync.imported,priceDate:universeSync.priceDate??null,quarterDate:universeSync.quarterDate??null,asOf:universeSync.asOf??null},note:"Active US MFI universe refreshed using the existing six-hour MFI cache. Selection settings and market-cap dates are recorded for audit; market caps are informational and are not accounting approval."});
      } catch(e) { return json({error:e instanceof Error?e.message:String(e),source:"EdgarTools universe discovery"},503); }
    }
    if (url.pathname==="/api/fundamentals/edgartools/ingest" && request.method==="POST") {
      if (!env.UNIVERSE_SYNC_TOKEN) return json({error:"UNIVERSE_SYNC_TOKEN is not configured"},503);
      if (request.headers.get("Authorization") !== "Bearer " + env.UNIVERSE_SYNC_TOKEN) return json({error:"Unauthorized"},401);
      try {
        const declaredLength=Number(request.headers.get("Content-Length")??0);
        if (declaredLength>8*1024*1024) return json({error:"Payload exceeds 8 MiB limit"},413);
        const raw=await request.text();
        if (new TextEncoder().encode(raw).byteLength>8*1024*1024) return json({error:"Payload exceeds 8 MiB limit"},413);
        const payload:any=JSON.parse(raw);
        if (payload?.primary_provider!=="EdgarTools" || !Array.isArray(payload?.companies) || payload.companies.length>100) return json({error:"Expected an EdgarTools report with at most 100 companies"},400);
        await ensureSchema(env);
        await env.DB.prepare("CREATE TABLE IF NOT EXISTS edgartools_filing_evidence (symbol TEXT NOT NULL,accession_key TEXT NOT NULL,market TEXT NOT NULL DEFAULT 'US',cik TEXT,accession TEXT,fiscal_period TEXT,form TEXT,filed_at TEXT,reporting_currency TEXT,provider_status TEXT NOT NULL,provider TEXT NOT NULL DEFAULT 'EdgarTools',provider_version TEXT,generated_at TEXT,payload_json TEXT NOT NULL,ingested_at TEXT NOT NULL,PRIMARY KEY(symbol,accession_key))").run();
        const now=new Date().toISOString();
        const accepted=payload.companies.map((company:any)=>{
          const symbol=String(company?.symbol??"").trim().toUpperCase();
          if (!/^[A-Z0-9.-]{1,15}$/.test(symbol)) throw new Error("Invalid ticker in EdgarTools report");
          const providerStatus=company?.provider_status ?? (company?.status==="extracted" ? "supported" : company?.status==="not_found_in_sec_company_index" ? "unsupported_provider" : "extraction_error");
          if (!["supported","unsupported_provider","extraction_error"].includes(providerStatus)) throw new Error("Invalid provider status for "+symbol);
          const filing=company?.filing??{};
          const accession=filing?.accession_number ? String(filing.accession_number) : filing?.accession ? String(filing.accession) : null;
          if (providerStatus==="supported" && (!accession || !(filing?.period_of_report??filing?.period))) throw new Error("Supported issuer "+symbol+" is missing filing accession or fiscal period");
          const accessionKey=accession??("STATUS:"+symbol);
          const serialized=JSON.stringify(company);
          if (serialized.length>2*1024*1024) throw new Error("Company payload too large for "+symbol);
          return {symbol,providerStatus,accession,accessionKey,filing,company,serialized};
        });
        let ingested=0;
        for(let i=0;i<accepted.length;i+=40) {
          const batch=accepted.slice(i,i+40).map((item:any)=>env.DB.prepare("INSERT INTO edgartools_filing_evidence (symbol,accession_key,market,cik,accession,fiscal_period,form,filed_at,reporting_currency,provider_status,provider,provider_version,generated_at,payload_json,ingested_at) VALUES (?, ?, 'US', ?, ?, ?, ?, ?, ?, ?, 'EdgarTools', ?, ?, ?, ?) ON CONFLICT(symbol,accession_key) DO UPDATE SET cik=excluded.cik,accession=excluded.accession,fiscal_period=excluded.fiscal_period,form=excluded.form,filed_at=excluded.filed_at,reporting_currency=excluded.reporting_currency,provider_status=excluded.provider_status,provider_version=excluded.provider_version,generated_at=excluded.generated_at,payload_json=excluded.payload_json,ingested_at=excluded.ingested_at").bind(item.symbol,item.accessionKey,item.company?.filing?.cik??null,item.accession,item.filing?.period_of_report??item.filing?.period??null,item.filing?.form??null,item.filing?.filing_date??item.filing?.filed_at??null,item.company?.reporting_currency_review?.currency??null,item.providerStatus,payload.edgartools_version??null,payload.generated_at??null,item.serialized,now));
          await env.DB.batch(batch);
          ingested+=batch.length;
        }
        return json({source:"EdgarTools",primary_provider:"EdgarTools",received:accepted.length,ingested,production_fundamentals_changed:false,rankings_changed:false,unsupported_provider:accepted.filter((x:any)=>x.providerStatus==="unsupported_provider").map((x:any)=>x.symbol),note:"Raw filing evidence only. No production fundamentals, ratios, eligibility or rankings were changed."});
      } catch(e) { return json({error:e instanceof Error?e.message:String(e),source:"EdgarTools ingestion"},400); }
    }
    if (url.pathname==="/api/fundamentals/edgartools/status" && request.method==="GET") {
      try {
        await ensureSchema(env);
        await env.DB.prepare("CREATE TABLE IF NOT EXISTS edgartools_filing_evidence (symbol TEXT NOT NULL,accession_key TEXT NOT NULL,market TEXT NOT NULL DEFAULT 'US',cik TEXT,accession TEXT,fiscal_period TEXT,form TEXT,filed_at TEXT,reporting_currency TEXT,provider_status TEXT NOT NULL,provider TEXT NOT NULL DEFAULT 'EdgarTools',provider_version TEXT,generated_at TEXT,payload_json TEXT NOT NULL,ingested_at TEXT NOT NULL,PRIMARY KEY(symbol,accession_key))").run();
        const summary=await env.DB.prepare("SELECT provider_status,COUNT(DISTINCT symbol) AS count,MAX(ingested_at) AS last_ingested_at FROM edgartools_filing_evidence GROUP BY provider_status ORDER BY provider_status").all<any>();
        const latest=await env.DB.prepare("SELECT symbol,provider_status,accession,fiscal_period,form,filed_at,reporting_currency,provider_version,ingested_at FROM edgartools_filing_evidence e WHERE ingested_at=(SELECT MAX(e2.ingested_at) FROM edgartools_filing_evidence e2 WHERE e2.symbol=e.symbol) ORDER BY symbol").all<any>();
        return json({primary_provider:"EdgarTools",storage:"raw filing evidence only",production_fundamentals_changed:false,summary:summary.results,latest:latest.results});
      } catch(e) { return json({error:e instanceof Error?e.message:String(e)},503); }
    }

    if (url.pathname==="/api/fundamentals/edgartools/resolve-preview" && request.method==="GET") {
      if (!env.UNIVERSE_SYNC_TOKEN) return json({error:"UNIVERSE_SYNC_TOKEN is not configured"},503);
      if (request.headers.get("Authorization") !== "Bearer " + env.UNIVERSE_SYNC_TOKEN) return json({error:"Unauthorized"},401);
      try {
        await ensureEdgarToolsEvidenceSchema(env);
        // INTENTIONAL: read-only resolver preview. It never writes stock_fundamentals,
        // stock_snapshot ratios, eligibility, or rankings.
        const rows=await env.DB.prepare(`SELECT m.symbol,m.company_name,e.provider_status,e.accession,e.fiscal_period,e.form,e.payload_json,e.ingested_at
          FROM stock_master m
          LEFT JOIN edgartools_filing_evidence e ON e.symbol=m.symbol AND e.accession_key=(
            SELECT e2.accession_key FROM edgartools_filing_evidence e2
            WHERE e2.symbol=m.symbol AND e2.market='US'
            ORDER BY e2.ingested_at DESC,e2.accession_key DESC LIMIT 1
          )
          WHERE m.market='US' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)
          ORDER BY m.symbol`).all<any>();
        const resolutions=rows.results.map((row:any)=>{
          let company:any=null;
          if(row.payload_json) {
            try { company=JSON.parse(row.payload_json); }
            catch { company=null; }
          }
          const result=resolveEdgarToolsEvidence(row.symbol,row.provider_status??null,row.accession??null,row.fiscal_period??null,company);
          return {...result,company_name:row.company_name,filing_form:row.form??null,evidence_ingested_at:row.ingested_at??null};
        });
        const summary={
          active_universe:resolutions.length,
          supported:resolutions.filter((x:any)=>x.provider_status==="supported").length,
          unsupported_provider:resolutions.filter((x:any)=>x.overall_status==="unsupported_provider").length,
          awaiting_evidence:resolutions.filter((x:any)=>x.overall_status==="awaiting_evidence").length,
          direct_ebit_candidates:resolutions.filter((x:any)=>x.ebit_status==="direct_reported_candidate_review_only").length,
          conventional_debt_candidates:resolutions.filter((x:any)=>x.enterprise_value_candidate_review?.conventional_debt_status==="identified_from_unique_current_and_noncurrent_components").length,
          net_debt_candidates:resolutions.filter((x:any)=>x.enterprise_value_candidate_review?.conventional_net_debt_candidate!==null).length,
          ambiguous_debt_inputs:resolutions.filter((x:any)=>x.enterprise_value_candidate_review?.conventional_debt_status==="incomplete_or_ambiguous_debt_inputs").length,
          review_required:resolutions.filter((x:any)=>x.overall_status==="review_required").length
        };
        return json({primary_provider:"EdgarTools",resolver:"deterministic-preview-v1",summary,resolutions,
          production_fundamentals_changed:false,rankings_changed:false,
          note:"Preview only. Direct EBIT and invested-capital candidates remain review-only; accounting scope flags are preserved. No production values or rankings are written."});
      } catch(e) { return json({error:e instanceof Error?e.message:String(e),source:"EdgarTools resolver preview"},503); }
    }


    if ((url.pathname==="/api/fundamentals/edgartools/ranking-preview" || url.pathname==="/api/fundamentals/edgartools/ranking-preview/public") && request.method==="GET") {
      const publicPreview=url.pathname.endsWith("/public");
      if (!publicPreview) {
        if (!env.UNIVERSE_SYNC_TOKEN) return json({error:"UNIVERSE_SYNC_TOKEN is not configured"},503);
        if (request.headers.get("Authorization") !== "Bearer " + env.UNIVERSE_SYNC_TOKEN) return json({error:"Unauthorized"},401);
      }
      try {
        await ensureEdgarToolsEvidenceSchema(env);
        const evidence=await env.DB.prepare(`SELECT m.symbol,m.company_name,e.provider_status,e.accession,e.fiscal_period,e.form,e.payload_json,e.ingested_at
          FROM stock_master m
          LEFT JOIN edgartools_filing_evidence e ON e.symbol=m.symbol AND e.accession_key=(
            SELECT e2.accession_key FROM edgartools_filing_evidence e2
            WHERE e2.symbol=m.symbol AND e2.market='US'
            ORDER BY e2.ingested_at DESC,e2.accession_key DESC LIMIT 1
          )
          WHERE m.market='US' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)
          ORDER BY m.symbol`).all<any>();
        const caps=await env.DB.prepare(`SELECT m.symbol,q.market_cap FROM stock_master m
          LEFT JOIN stock_snapshot q ON q.symbol=m.symbol AND q.market='US'
          WHERE m.market='US' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)`).all<any>();
        const capBySymbol=new Map(caps.results.map((x:any)=>[x.symbol,x.market_cap==null?null:Number(x.market_cap)]));
        const rows=evidence.results.map((row:any)=>{
          let company:any=null;
          if(row.payload_json) { try { company=JSON.parse(row.payload_json); } catch { company=null; } }
          const resolved=resolveEdgarToolsEvidence(row.symbol,row.provider_status??null,row.accession??null,row.fiscal_period??null,company);
          return {...resolved,company_name:row.company_name,market_cap:capBySymbol.get(row.symbol)??null};
        });
        const result=buildMfiRankingPreview(rows);
        const response={...result,as_of:new Date().toISOString(),price_source:"Magic Formula Investing universe market-cap snapshot"};
        if (publicPreview) {
          return json({...response,rankings:result.rankings.map((row:any)=>({
            symbol:row.symbol,company_name:row.company_name,market_cap:row.market_cap,
            earnings_yield:row.earnings_yield,return_on_capital:row.return_on_capital,
            earnings_yield_rank:row.earnings_yield_rank,return_on_capital_rank:row.return_on_capital_rank,
            magic_formula_score:row.magic_formula_score,magic_formula_rank:row.magic_formula_rank,
            ranking_eligible:row.ranking_eligible,exclusion_reasons:row.exclusion_reasons,review_flags:row.review_flags
          }))});
        }
        return json(response);
      } catch(e) { return json({error:e instanceof Error?e.message:String(e),source:"MFI shadow ranking preview"},503); }
    }
    if (url.pathname==="/api/fundamentals/legacy-debt-shadow-preview" && request.method==="POST") {
      // SHADOW ONLY: read-only SELECTs plus SEC fetches. No production writes, no ranking changes.
      if (!env.UNIVERSE_SYNC_TOKEN) return json({error:"UNIVERSE_SYNC_TOKEN is not configured"},503);
      if (request.headers.get("Authorization") !== "Bearer " + env.UNIVERSE_SYNC_TOKEN) return json({error:"Unauthorized"},401);
      try {
        await ensureSchema(env);
        const payload:any=await request.json();
        const requested=Array.isArray(payload.symbols)?payload.symbols:[payload.symbol];
        const selected=[...new Set(requested.map((value:any)=>String(value??"").trim().toUpperCase()).filter((value:string)=>/^[A-Z0-9.-]{1,15}$/.test(value)))];
        if (!selected.length || selected.length>10) return json({error:"Provide between 1 and 10 valid US ticker symbols"},400);
        const results=[];
        for(const symbol of selected) {
          const row=await env.DB.prepare(`SELECT m.symbol,m.company_name,cm.cik,f.fiscal_period AS legacy_fiscal_period,
            f.filed_at AS legacy_filed_at,f.total_debt AS legacy_total_debt
            FROM stock_master m LEFT JOIN sec_company_map cm ON cm.symbol=m.symbol
            LEFT JOIN stock_fundamentals f ON f.symbol=m.symbol AND f.market='US'
            WHERE m.market='US' AND m.symbol=? AND m.listing_status='active'
            AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)`).bind(symbol).first<any>();
          if(!row) { results.push({symbol,state:"not_in_active_us_universe"}); continue; }
          const base={symbol,company_name:row.company_name,cik:row.cik??null,
            legacy_total_debt:row.legacy_total_debt==null?null:Number(row.legacy_total_debt)};
          if(!row.cik || row.cik==="UNMAPPED") { results.push({...base,state:"sec_cik_unmapped"}); continue; }
          try {
            const response=await fetch("https://data.sec.gov/api/xbrl/companyfacts/CIK"+String(row.cik).padStart(10,"0")+".json",
              {headers:{"User-Agent":"Magic Screen/1.0 support@binalah.co","Accept":"application/json"}});
            if(!response.ok) { results.push({...base,state:"sec_companyfacts_error",http_status:response.status}); continue; }
            const facts:any=await response.json();
            const anchorTags=["OperatingIncomeLoss","OperatingProfitLoss","ProfitLossFromOperatingActivities","Revenues","Revenue",
              "RevenueFromContractWithCustomerExcludingAssessedTax","RevenueFromContractWithCustomerIncludingAssessedTax",
              "SalesRevenueNet","SalesRevenueGoodsNet","SalesRevenueServicesNet"];
            const annual=["us-gaap","ifrs-full"].flatMap(t=>anchorTags.flatMap(tag=>facts?.facts?.[t]?.[tag]?.units?.USD??[]))
              .filter((x:any)=>x.val!=null&&x.start&&x.end&&["10-K","20-F","40-F"].includes(x.form)
                &&(Date.parse(x.end)-Date.parse(x.start))/86400000>=330&&(Date.parse(x.end)-Date.parse(x.start))/86400000<=400)
              .sort((a:any,b:any)=>b.end.localeCompare(a.end)||b.filed.localeCompare(a.filed));
            const anchor=annual.find((x:any)=>
              (!row.legacy_fiscal_period||x.end===row.legacy_fiscal_period)&&(!row.legacy_filed_at||x.filed===row.legacy_filed_at)
            )??annual.find((x:any)=>!row.legacy_fiscal_period||x.end===row.legacy_fiscal_period)??annual[0];
            if(!anchor?.accn) { results.push({...base,state:"no_annual_usd_anchor_found"}); continue; }
            results.push({...base,state:"shadow_evaluated",sec_company_name:facts?.entityName??null,
              anchor:{accession:anchor.accn,form:anchor.form,fiscal_period:anchor.end,filed:anchor.filed},
              shadow:resolveLegacyDebtShadow(facts,anchor.end,anchor.accn)});
          } catch(error) {
            results.push({...base,state:"sec_fetch_error",error:error instanceof Error?error.message:String(error)});
          }
        }
        return json({source:"SEC EDGAR Company Facts",mode:"shadow_read_only",label:"shadow candidate, not production",results,
          production_fundamentals_changed:false,rankings_changed:false,production_write:false});
      } catch(error) { return json({error:error instanceof Error?error.message:String(error),source:"Legacy SEC debt shadow preview"},503); }
    }
    if (url.pathname==="/api/fundamentals/legacy-debt-diagnostic" && request.method==="POST") {
      if (!env.UNIVERSE_SYNC_TOKEN) return json({error:"UNIVERSE_SYNC_TOKEN is not configured"},503);
      if (request.headers.get("Authorization") !== "Bearer " + env.UNIVERSE_SYNC_TOKEN) return json({error:"Unauthorized"},401);
      try {
        await ensureSchema(env);
        const payload:any=await request.json();
        const requested=Array.isArray(payload.symbols)?payload.symbols:[payload.symbol];
        const selected=[...new Set(requested.map((value:any)=>String(value??"").trim().toUpperCase()).filter((value:string)=>/^[A-Z0-9.-]{1,15}$/.test(value)))];
        if (!selected.length || selected.length>10) return json({error:"Provide between 1 and 10 valid US ticker symbols"},400);
        const results=[];
        for(const symbol of selected) {
          const legacy=await env.DB.prepare(`SELECT m.symbol,m.company_name,cm.cik,cm.updated_at AS cik_mapping_updated_at,
            f.status AS legacy_status,f.source AS legacy_source,f.updated_at AS legacy_updated_at,
            f.fiscal_period AS legacy_fiscal_period,f.filed_at AS legacy_filed_at,
            f.ebit AS legacy_ebit,f.total_debt AS legacy_total_debt,f.cash AS legacy_cash,
            f.current_assets AS legacy_current_assets,f.current_liabilities AS legacy_current_liabilities,
            f.net_ppe AS legacy_net_ppe
            FROM stock_master m LEFT JOIN sec_company_map cm ON cm.symbol=m.symbol
            LEFT JOIN stock_fundamentals f ON f.symbol=m.symbol AND f.market='US'
            WHERE m.market='US' AND m.symbol=? AND m.listing_status='active'
            AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)`).bind(symbol).first<any>();
          if(!legacy) { results.push({symbol,state:"not_in_active_us_universe"}); continue; }
          const base={symbol,company_name:legacy.company_name,cik:legacy.cik??null,
            cik_mapping_updated_at:legacy.cik_mapping_updated_at??null,legacy:{status:legacy.legacy_status??null,
              source:legacy.legacy_source??null,updated_at:legacy.legacy_updated_at??null,
              fiscal_period:legacy.legacy_fiscal_period??null,filed_at:legacy.legacy_filed_at??null,
              ebit:legacy.legacy_ebit==null?null:Number(legacy.legacy_ebit),
              total_debt:legacy.legacy_total_debt==null?null:Number(legacy.legacy_total_debt),
              cash:legacy.legacy_cash==null?null:Number(legacy.legacy_cash),
              current_assets:legacy.legacy_current_assets==null?null:Number(legacy.legacy_current_assets),
              current_liabilities:legacy.legacy_current_liabilities==null?null:Number(legacy.legacy_current_liabilities),
              net_ppe:legacy.legacy_net_ppe==null?null:Number(legacy.legacy_net_ppe)}};
          if(!legacy.cik || legacy.cik==="UNMAPPED") { results.push({...base,state:"sec_cik_unmapped"}); continue; }
          try {
            const response=await fetch("https://data.sec.gov/api/xbrl/companyfacts/CIK"+String(legacy.cik).padStart(10,"0")+".json",
              {headers:{"User-Agent":"Magic Screen/1.0 support@binalah.co","Accept":"application/json"}});
            if(!response.ok) { results.push({...base,state:"sec_companyfacts_error",http_status:response.status}); continue; }
            const facts:any=await response.json();
            const anchorTags=["OperatingIncomeLoss","OperatingProfitLoss","ProfitLossFromOperatingActivities","Revenues","Revenue",
              "RevenueFromContractWithCustomerExcludingAssessedTax","RevenueFromContractWithCustomerIncludingAssessedTax",
              "SalesRevenueNet","SalesRevenueGoodsNet","SalesRevenueServicesNet"];
            const annual=["us-gaap","ifrs-full"].flatMap(t=>anchorTags.flatMap(tag=>facts?.facts?.[t]?.[tag]?.units?.USD??[]))
              .filter((x:any)=>x.val!=null&&x.start&&x.end&&["10-K","20-F","40-F"].includes(x.form)
                &&(Date.parse(x.end)-Date.parse(x.start))/86400000>=330&&(Date.parse(x.end)-Date.parse(x.start))/86400000<=400)
              .sort((a:any,b:any)=>b.end.localeCompare(a.end)||b.filed.localeCompare(a.filed));
            // Reproduce the stored legacy record's period/filed anchor where available.
            const anchor=annual.find((x:any)=>
              (!legacy.legacy_fiscal_period||x.end===legacy.legacy_fiscal_period)
              &&(!legacy.legacy_filed_at||x.filed===legacy.legacy_filed_at)
            )??annual.find((x:any)=>!legacy.legacy_fiscal_period||x.end===legacy.legacy_fiscal_period)??annual[0];
            if(!anchor?.accn) { results.push({...base,state:"no_annual_usd_anchor_found"}); continue; }
            results.push({...base,state:"diagnosed",sec_company_name:facts?.entityName??null,
              sec_cik:facts?.cik??null,diagnostic:diagnoseLegacyDebtFacts(facts,anchor.end,anchor.accn)});
          } catch(error) {
            results.push({...base,state:"sec_fetch_error",error:error instanceof Error?error.message:String(error)});
          }
        }
        return json({source:"SEC EDGAR Company Facts",mode:"read_only",results,
          production_fundamentals_changed:false,rankings_changed:false,production_write:false});
      } catch(error) { return json({error:error instanceof Error?error.message:String(error),source:"Legacy SEC debt diagnostic"},503); }
    }
    if (url.pathname==="/api/fundamentals/edgartools/reconciliation-preview" && request.method==="GET") {
      if (!env.UNIVERSE_SYNC_TOKEN) return json({error:"UNIVERSE_SYNC_TOKEN is not configured"},503);
      if (request.headers.get("Authorization") !== "Bearer " + env.UNIVERSE_SYNC_TOKEN) return json({error:"Unauthorized"},401);
      try {
        await ensureEdgarToolsEvidenceSchema(env);
        // INTENTIONAL: compare legacy production fundamentals with accession-bound EdgarTools candidates without writing either side.
        const rows=await env.DB.prepare(`SELECT m.symbol,m.company_name,
          q.market_cap AS current_market_cap,q.updated_at AS market_cap_updated_at,
          f.status AS legacy_status,f.source AS legacy_source,f.fiscal_period AS legacy_fiscal_period,f.filed_at AS legacy_filed_at,
          f.ebit AS legacy_ebit,f.current_assets AS legacy_current_assets,f.current_liabilities AS legacy_current_liabilities,
          f.net_ppe AS legacy_net_ppe,f.total_debt AS legacy_total_debt,f.cash AS legacy_cash,
          f.market_cap AS legacy_market_cap,f.earnings_yield AS legacy_stored_earnings_yield,
          f.return_on_capital AS legacy_stored_return_on_capital,
          e.provider_status,e.accession,e.fiscal_period AS edgar_fiscal_period,e.form,e.payload_json
          FROM stock_master m
          LEFT JOIN stock_snapshot q ON q.symbol=m.symbol AND q.market='US'
          LEFT JOIN stock_fundamentals f ON f.symbol=m.symbol AND f.market='US'
          LEFT JOIN edgartools_filing_evidence e ON e.symbol=m.symbol AND e.accession_key=(
            SELECT e2.accession_key FROM edgartools_filing_evidence e2
            WHERE e2.symbol=m.symbol AND e2.market='US'
            ORDER BY e2.ingested_at DESC,e2.accession_key DESC LIMIT 1
          )
          WHERE m.market='US' AND m.listing_status='active' AND EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)
          ORDER BY m.symbol`).all<any>();
        const reconciliationRows=rows.results.map((row:any)=>{
          let company:any=null;
          if(row.payload_json) { try { company=JSON.parse(row.payload_json); } catch { company=null; } }
          const resolved=resolveEdgarToolsEvidence(row.symbol,row.provider_status??null,row.accession??null,row.edgar_fiscal_period??null,company);
          return {
            symbol:row.symbol,company_name:row.company_name,
            current_market_cap:row.current_market_cap==null?null:Number(row.current_market_cap),
            market_cap_updated_at:row.market_cap_updated_at??null,
            legacy_status:row.legacy_status??null,legacy_source:row.legacy_source??null,
            legacy_fiscal_period:row.legacy_fiscal_period??null,legacy_filed_at:row.legacy_filed_at??null,
            legacy_ebit:row.legacy_ebit==null?null:Number(row.legacy_ebit),
            legacy_current_assets:row.legacy_current_assets==null?null:Number(row.legacy_current_assets),
            legacy_current_liabilities:row.legacy_current_liabilities==null?null:Number(row.legacy_current_liabilities),
            legacy_net_ppe:row.legacy_net_ppe==null?null:Number(row.legacy_net_ppe),
            legacy_total_debt:row.legacy_total_debt==null?null:Number(row.legacy_total_debt),
            legacy_cash:row.legacy_cash==null?null:Number(row.legacy_cash),
            legacy_market_cap:row.legacy_market_cap==null?null:Number(row.legacy_market_cap),
            legacy_stored_earnings_yield:row.legacy_stored_earnings_yield==null?null:Number(row.legacy_stored_earnings_yield),
            legacy_stored_return_on_capital:row.legacy_stored_return_on_capital==null?null:Number(row.legacy_stored_return_on_capital),
            edgar:{...resolved,filing_form:row.form??null}
          };
        });
        return json(buildFundamentalsReconciliationPreview(reconciliationRows,new Date().toISOString()));
      } catch(e) { return json({error:e instanceof Error?e.message:String(e),source:"Legacy vs EdgarTools reconciliation preview"},503); }
    }
    if (url.pathname==="/api/fundamentals/diagnose-extensions" && request.method==="POST") {
      if (!env.UNIVERSE_SYNC_TOKEN) return json({error:"UNIVERSE_SYNC_TOKEN is not configured"},503);
      if (request.headers.get("Authorization") !== "Bearer " + env.UNIVERSE_SYNC_TOKEN) return json({error:"Unauthorized"},401);
      try {
        // INTENTIONAL: initialize D1 tables here so the protected diagnostic works independently
        // of whether the screener or another API route has been opened first.
        await ensureSchema(env);
        const payload:any=await request.json();
        const symbol=String(payload.symbol??"").trim().toUpperCase();
        if (!/^[A-Z0-9.-]{1,15}$/.test(symbol)) return json({error:"A valid US ticker symbol is required"},400);
        return json(await diagnoseSecExtensionFacts(env,symbol));
      } catch(e) { return json({error:e instanceof Error?e.message:String(e),source:"SEC filing XBRL extension diagnostic"},503); }
    }
    if (url.pathname==="/api/fundamentals/edgartools/ai-review/batch" && (request.method==="GET" || request.method==="POST")) {
      if (!env.UNIVERSE_SYNC_TOKEN) return json({error:"UNIVERSE_SYNC_TOKEN is not configured"},503);
      if (request.headers.get("Authorization") !== "Bearer " + env.UNIVERSE_SYNC_TOKEN) return json({error:"Unauthorized"},401);
      try {
        await ensureSchema(env);
        await env.DB.prepare(`CREATE TABLE IF NOT EXISTS edgartools_filing_evidence (
          symbol TEXT NOT NULL,accession_key TEXT NOT NULL,market TEXT NOT NULL DEFAULT 'US',cik TEXT,accession TEXT,
          fiscal_period TEXT,form TEXT,filed_at TEXT,reporting_currency TEXT,provider_status TEXT NOT NULL,
          provider TEXT NOT NULL DEFAULT 'EdgarTools',provider_version TEXT,generated_at TEXT,payload_json TEXT NOT NULL,
          ingested_at TEXT NOT NULL,PRIMARY KEY(symbol,accession_key))`).run();
        const active=await env.DB.prepare("SELECT m.symbol FROM stock_master m WHERE m.market='US' AND m.listing_status='active' AND "+US_ACTIVE_UNIVERSE_SQL+" ORDER BY m.symbol").all<any>();
        const symbolsActive=active.results.map((row:any)=>String(row.symbol));
        const loadIssuer=async(symbol:string)=>{
          const row=await env.DB.prepare(`SELECT e.provider_status,e.accession,e.fiscal_period,e.form,e.payload_json
            FROM edgartools_filing_evidence e WHERE e.symbol=? AND e.market='US'
            ORDER BY e.ingested_at DESC,e.accession_key DESC LIMIT 1`).bind(symbol).first<any>();
          if(!row) return {state:"awaiting_evidence"};
          if(row.provider_status!=="supported"||!row.payload_json) return {state:"unsupported"};
          const company=JSON.parse(row.payload_json);
          // Deterministic resolver first: only escalations it leaves unresolved are eligible for Gemini.
          const resolver=resolveEdgarToolsEvidence(symbol,row.provider_status,row.accession,row.fiscal_period,company);
          return {state:"supported",accession:row.accession,fiscalPeriod:row.fiscal_period,company,resolver,escalations:listGeminiAccountingEscalations(symbol,company,resolver)};
        };
        if (request.method==="GET") {
          // Read-only coverage and queue status. Never exposes the API key.
          const tasks=await env.DB.prepare("SELECT task,status,COUNT(*) AS n FROM gemini_accounting_review_cache GROUP BY task,status").all<any>().catch(()=>({results:[]} as any));
          const plan=await runBatchPage({symbols:symbolsActive,cursor:null,loadIssuer,runReview:async()=>({}),maxNewCalls:0,maxTasks:0,dryRun:true,includeFullScope:url.searchParams.get("include_full_scope")==="1"});
          let modelCheck:any=null;
          if(url.searchParams.get("check_models")==="1" && env.GEMINI_API_KEY) {
            try {
              const res=await fetch("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200",{headers:{"x-goog-api-key":env.GEMINI_API_KEY}});
              if(res.ok){
                const body:any=await res.json();
                const available=new Set((body.models??[]).map((m:any)=>String(m.name).replace(/^models\//,"")));
                const configured=getGeminiModelCandidates(env.GEMINI_MODEL,(env as any).GEMINI_MODEL_FALLBACKS);
                modelCheck={configured:configured.map((model:string)=>({model,available:available.has(model)}))};
              } else modelCheck={error:"Model list HTTP "+res.status};
            } catch(e){ modelCheck={error:"Model list request failed"}; }
          }
          return json({active_universe:symbolsActive.length,gemini_api_key_configured:!!env.GEMINI_API_KEY,gemini_model_configured:env.GEMINI_MODEL??null,model_check:modelCheck,
            unsupported:plan.counts.UNSUPPORTED,awaiting_evidence:plan.counts.AWAITING_EVIDENCE,deterministic_only:plan.counts.SKIPPED_DETERMINISTIC,
            issuers_with_pending_tasks:plan.issuers.filter((i:any)=>i.tasks.length>0).length,pending_tasks_planned:plan.counts.PENDING,
            cached_reviews_by_task_status:tasks.results,coverage_note:"Unsupported and awaiting-evidence issuers remain visible and are not dropped. Quota exhaustion is never cached as a completed review.",
            production_write:false,production_fundamentals_changed:false,rankings_changed:false});
        }
        const body=JSON.parse((await request.text())||"{}");
        const dryRun=body.dry_run===true;
        if(!dryRun && !env.GEMINI_API_KEY) return json({error:"GEMINI_API_KEY is not configured as a Worker secret"},503);
        let selectedSymbols=symbolsActive;
        if(body.symbols!==undefined) {
          if(!Array.isArray(body.symbols)||body.symbols.length<1||body.symbols.length>30||
            body.symbols.some((value:any)=>typeof value!=="string"||!/^[A-Z0-9.-]{1,15}$/.test(value.trim().toUpperCase())))
            return json({error:"symbols must be an array of 1-30 valid ticker strings"},400);
          const requestedValues=body.symbols as string[];
          const requested=[...new Set(requestedValues.map((value:string)=>value.trim().toUpperCase()))];
          const inactive=requested.filter((symbol:string)=>!symbolsActive.includes(symbol));
          if(inactive.length) return json({error:"Requested symbols are not in the active US universe",symbols:inactive},400);
          selectedSymbols=symbolsActive.filter((symbol:string)=>requested.includes(symbol));
        }
        const page=await runBatchPage({symbols:selectedSymbols,cursor:typeof body.cursor==="string"?body.cursor:null,loadIssuer,
          runReview:(input:any)=>runGeminiAccountingReview(env,{...input,model:env.GEMINI_MODEL}),
          maxNewCalls:Math.min(5,Math.max(1,Math.floor(Number(body.max_new_calls??2)))),
          maxTasks:Math.min(25,Math.max(1,Math.floor(Number(body.max_tasks??12)))),
          includeFullScope:body.include_full_scope===true,dryRun});
        return json({...page,active_universe:symbolsActive.length,ai_review_only:true,production_write:false,production_fundamentals_changed:false,rankings_changed:false});
      } catch(e) { return json({error:e instanceof Error?e.message:String(e),source:"Gemini batch accounting review"},503); }
    }
    if (url.pathname==="/api/fundamentals/edgartools/ai-review" && (request.method==="GET" || request.method==="POST")) {
      if (!env.UNIVERSE_SYNC_TOKEN) return json({error:"UNIVERSE_SYNC_TOKEN is not configured"},503);
      if (request.headers.get("Authorization") !== "Bearer " + env.UNIVERSE_SYNC_TOKEN) return json({error:"Unauthorized"},401);
      try {
        await ensureSchema(env);
        let payload:any={};
        if(request.method==="POST") {
          const body=await request.text();
          if(new TextEncoder().encode(body).byteLength>4096) return json({error:"AI review request exceeds 4 KiB limit"},413);
          payload=body?JSON.parse(body):{};
        }
        const symbol=String(payload.symbol??url.searchParams.get("symbol")??"").trim().toUpperCase();
        if (!/^[A-Z0-9.-]{1,15}$/.test(symbol)) return json({error:"A valid US ticker symbol is required"},400);
        await env.DB.prepare(`CREATE TABLE IF NOT EXISTS edgartools_filing_evidence (
          symbol TEXT NOT NULL,accession_key TEXT NOT NULL,market TEXT NOT NULL DEFAULT 'US',cik TEXT,accession TEXT,
          fiscal_period TEXT,form TEXT,filed_at TEXT,reporting_currency TEXT,provider_status TEXT NOT NULL,
          provider TEXT NOT NULL DEFAULT 'EdgarTools',provider_version TEXT,generated_at TEXT,payload_json TEXT NOT NULL,
          ingested_at TEXT NOT NULL,PRIMARY KEY(symbol,accession_key))`).run();
        const row=await env.DB.prepare(`SELECT e.provider_status,e.accession,e.fiscal_period,e.form,e.payload_json
          FROM edgartools_filing_evidence e
          WHERE e.symbol=? AND e.market='US'
          ORDER BY e.ingested_at DESC,e.accession_key DESC LIMIT 1`).bind(symbol).first<any>();
        if (!row || row.provider_status!=="supported" || !row.payload_json) return json({symbol,status:"evidence_unavailable",escalations:[],note:"No supported EdgarTools annual filing evidence is available."},404);
        const company=JSON.parse(row.payload_json);
        const resolver=resolveEdgarToolsEvidence(symbol,row.provider_status,row.accession,row.fiscal_period,company);
        if (request.method==="GET" || payload.preview===true) {
          return json({symbol,accession:row.accession,fiscal_period:row.fiscal_period,resolver_status:resolver.overall_status,
            escalations:listGeminiAccountingEscalations(symbol,company,resolver),
            production_write:false,production_fundamentals_changed:false,rankings_changed:false,
            note:"Preview only. Gemini is called only for explicitly unresolved accounting interpretation tasks."});
        }
        if (!env.GEMINI_API_KEY) return json({error:"GEMINI_API_KEY is not configured as a Worker secret"},503);
        const task=String(payload.task??"");
        return json(await runGeminiAccountingReview(env,{symbol,accession:row.accession,fiscalPeriod:row.fiscal_period,
          company,resolver,task,model:env.GEMINI_MODEL}));
      } catch(e) { return json({error:e instanceof Error?e.message:String(e),source:"EdgarTools + Gemini accounting review"},503); }
    }
    if ((url.pathname==="/api/fundamentals/edgartools/ai-review/history" && request.method==="GET")
      || (url.pathname==="/api/fundamentals/edgartools/ai-review/decisions" && (request.method==="GET" || request.method==="POST"))) {
      if (!env.UNIVERSE_SYNC_TOKEN) return json({error:"UNIVERSE_SYNC_TOKEN is not configured"},503);
      if (request.headers.get("Authorization") !== "Bearer " + env.UNIVERSE_SYNC_TOKEN) return json({error:"Unauthorized"},401);
      // Audit ledger only: touches gemini_accounting_review_* tables, never production fundamentals or rankings.
      const audit={production_write:false,production_fundamentals_changed:false,rankings_changed:false};
      try {
        const isDecisions=url.pathname.endsWith("/decisions");
        if (request.method==="POST") {
          const body=await request.text();
          if(new TextEncoder().encode(body).byteLength>MAX_DECISION_BODY_BYTES) return json({error:"Decision request exceeds 8 KiB limit"},413);
          let payload:any; try { payload=JSON.parse(body||"{}"); } catch { return json({error:"Invalid JSON body"},400); }
          const result:any=await recordReviewDecision(env,payload);
          return result.ok ? json({...result.decision,...audit},201) : json({error:result.error},result.status);
        }
        const page:any=parsePageParams(url.searchParams);
        if(!page.ok) return json({error:page.error},400);
        const symbolParam=url.searchParams.get("symbol");
        const symbol=symbolParam?symbolParam.trim().toUpperCase():null;
        if(symbol && !/^[A-Z0-9.-]{1,15}$/.test(symbol)) return json({error:"A valid US ticker symbol is required"},400);
        const task=url.searchParams.get("task");
        if(task && !REVIEW_TASKS.has(task)) return json({error:"Unsupported accounting review task"},400);
        const cacheKey=url.searchParams.get("cache_key");
        if(cacheKey && !/^[0-9a-f]{64}$/.test(cacheKey)) return json({error:"cache_key must be a 64-character hex key"},400);
        const rows=isDecisions
          ? await listReviewDecisions(env,{symbol,task,cacheKey,limit:page.limit,offset:page.offset})
          : await listReviewHistory(env,{symbol,task,limit:page.limit,offset:page.offset});
        return json({[isDecisions?"decisions":"history"]:rows,limit:page.limit,offset:page.offset,
          reviewer_identity_verified:false,...audit});
      } catch(e) { return json({error:e instanceof Error?e.message:String(e),source:"Gemini accounting review audit ledger"},503); }
    }
    if (url.pathname==="/api/ai/fundamentals/extract" && request.method==="POST") {
      return json({error:"This legacy Company Facts tag-discovery endpoint is retired. Use /api/fundamentals/edgartools/ai-review for cached, ambiguity-only review."},410);
    }
    if (url.pathname==="/api/mfi/screen") {
      try {
        const minimumMarketCap = Math.min(5000000,Math.max(50,Number(url.searchParams.get("minimumMarketCap") ?? 50)));
        const select30 = url.searchParams.get("select30") !== "false";
        const forceRefresh = url.searchParams.get("force")==="1";
        const result = await syncMagicFormulaUniverse(env,minimumMarketCap,select30,forceRefresh);
        return json(result);
      } catch(e) { return json({error:e instanceof Error?e.message:String(e),source:"Magic Formula Investing"},503); }
    }
    if (url.pathname==="/api/health") return json({ok:true,service:"magic-screen",environment:env.APP_ENV ?? "development"});
    if (url.pathname==="/api/admin/cleanup-sec-universe" && request.method==="POST") {
      if (!env.UNIVERSE_SYNC_TOKEN) return json({error:"UNIVERSE_SYNC_TOKEN is not configured"},503);
      if (request.headers.get("Authorization") !== "Bearer " + env.UNIVERSE_SYNC_TOKEN) return json({error:"Unauthorized"},401);
      try {
        // INTENTIONAL: do not call ensureSchema here. This is a targeted cleanup against
        // existing production tables and must not trigger unrelated schema/seed writes.
        const payload:any=await request.json();
        const action=String(payload.action??"preview");
        if(action==="preview") {
          const counts=await env.DB.prepare(`SELECT
            COUNT(*) AS sec_source_rows,
            COALESCE(SUM(CASE WHEN EXISTS (
              SELECT 1 FROM stock_snapshot q WHERE q.symbol=m.symbol AND q.market='US' AND q.provider='Magic Formula Investing'
            ) THEN 1 ELSE 0 END),0) AS protected_mfi_rows,
            COALESCE(SUM(CASE WHEN NOT EXISTS (
              SELECT 1 FROM stock_snapshot q WHERE q.symbol=m.symbol AND q.market='US' AND q.provider='Magic Formula Investing'
            ) THEN 1 ELSE 0 END),0) AS deletion_candidates
            FROM stock_master m
            WHERE m.market='US' AND m.source='SEC company_tickers_exchange.json' AND NOT EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)`).first<any>();
          return json({action:"preview",...counts,delete_filter:"US stock_master rows with SEC source, excluding rows whose stock_snapshot provider is Magic Formula Investing",note:"No rows changed. MFI-marked rows are protected."});
        }
        if(action==="delete") {
          const batchSize=Math.min(5000,Math.max(100,Math.floor(Number(payload.batchSize??5000))));
          const result=await env.DB.prepare(`DELETE FROM stock_master
            WHERE rowid IN (
              SELECT m.rowid FROM stock_master m
              WHERE m.market='US' AND m.source='SEC company_tickers_exchange.json'
                AND NOT EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)
                AND NOT EXISTS (
                  SELECT 1 FROM stock_snapshot q
                  WHERE q.symbol=m.symbol AND q.market='US' AND q.provider='Magic Formula Investing'
                )
              LIMIT ?
            )`).bind(batchSize).run();
          const remaining=await env.DB.prepare(`SELECT COUNT(*) AS count FROM stock_master m
            WHERE m.market='US' AND m.source='SEC company_tickers_exchange.json'
              AND NOT EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)
              AND NOT EXISTS (
                SELECT 1 FROM stock_snapshot q
                WHERE q.symbol=m.symbol AND q.market='US' AND q.provider='Magic Formula Investing'
              )`).first<any>();
          return json({action:"delete",deleted:result.meta.changes??0,remaining:remaining?.count??null,batchSize,note:"One bounded batch only. Repeat after reviewing the result; protected MFI rows are excluded."});
        }
        return json({error:"action must be preview or delete"},400);
      } catch(e) { return json({error:e instanceof Error?e.message:String(e),source:"SEC universe cleanup"},503); }
    }
    if (url.pathname==="/api/universe/us/stocks" && (request.method==="POST" || request.method==="DELETE")) {
      // Frontend-managed US universe membership. Protected by the same bearer token as other universe writes.
      if (!env.UNIVERSE_SYNC_TOKEN) return json({error:"UNIVERSE_SYNC_TOKEN is not configured"},503);
      if (request.headers.get("Authorization") !== "Bearer " + env.UNIVERSE_SYNC_TOKEN) return json({error:"Unauthorized"},401);
      try {
        await ensureSchema(env);
        const now=new Date().toISOString();
        if (request.method==="DELETE") {
          const symbol=normaliseUsSymbol(url.searchParams.get("symbol"));
          if(!symbol) return json({error:"Invalid US ticker symbol"},400);
          const result=await removeFrontendStock(env.DB,symbol,now);
          return json({...result,note:result.status==="removed"?"Only the frontend membership was removed. The stock stays active if another source still includes it. Published ranks are cleared if the active universe changed.":"No active frontend membership for this symbol; MFI.com memberships cannot be removed here."},result.status==="not_found"?404:200);
        }
        const payload:any=await request.json();
        const symbol=normaliseUsSymbol(payload.symbol);
        if(!symbol) return json({error:"Invalid US ticker symbol. Use the plain US ticker, for example AAPL or BRK-B."},400);
        // Best-effort name/CIK check against SEC's directory. It is a validation aid only: the directory is
        // never imported as a universe, and unmapped tickers stay visible as unsupported in coverage.
        let secMatch:{name:string|null;cik:string}|null=null;
        try {
          const res=await fetch("https://www.sec.gov/files/company_tickers.json",{headers:{"User-Agent":"Magic Screen/1.0 support@binalah.co","Accept-Encoding":"gzip, deflate"},signal:AbortSignal.timeout(6000)});
          if(res.ok){
            const dir:any=await res.json();
            const norm=(v:string)=>v.toUpperCase().replace(/[^A-Z0-9]/g,"");
            const hit:any=Object.values(dir).find((row:any)=>norm(String(row.ticker))===norm(symbol));
            if(hit) secMatch={name:hit.title?String(hit.title):null,cik:String(hit.cik_str).padStart(10,"0")};
          }
        } catch { /* validation aid only */ }
        const capMillions=payload.market_cap_millions==null?null:Number(payload.market_cap_millions);
        const result=await addFrontendStock(env.DB,{symbol,companyName:payload.company_name||secMatch?.name||symbol,marketCapMillions:capMillions,metadata:{sec_directory_match:!!secMatch}},now);
        return json({...result,sec_directory_match:!!secMatch,awaiting_market_cap:capMillions==null,note:"Added to the US universe. It enters the normal quote, SEC extraction, review and ranking gates. Published ranks are cleared while the new candidate lacks current complete fundamentals."});
      } catch (e) { return json({error:e instanceof Error?e.message:String(e)},400); }
    }
    if (url.pathname==="/api/universe/import-my" && request.method==="POST") {
      if (!env.UNIVERSE_SYNC_TOKEN) return json({error:"UNIVERSE_SYNC_TOKEN is not configured"},503);
      if (request.headers.get("Authorization") !== "Bearer " + env.UNIVERSE_SYNC_TOKEN) return json({error:"Unauthorized"},401);
      try {
        await ensureSchema(env);
        const payload: any = await request.json();
        if (!Array.isArray(payload.rows) || payload.rows.length > 5000) return json({error:"Expected rows array, maximum 5000"},400);
        const now = new Date().toISOString();
        let imported = 0;
        for (let i=0; i<payload.rows.length; i+=80) {
          const batch = payload.rows.slice(i,i+80).map((r: any) => {
            const rawSymbol = String(r.symbol || "").trim().toUpperCase();
            const symbol = rawSymbol && !rawSymbol.endsWith(".KL") ? rawSymbol + ".KL" : rawSymbol;
            const companyName = String(r.company_name || r.name || "").trim();
            if (!/^[0-9A-Z][0-9A-Z.-]{0,14}\.KL$/.test(symbol) || !companyName) return null;
            return env.DB.prepare("INSERT INTO stock_master (symbol,market,company_name,currency,exchange,sector,listing_status,source,source_updated_at) VALUES (?, 'MY', ?, 'MYR', ?, ?, ?, ?, ?) ON CONFLICT(symbol,market) DO UPDATE SET company_name=excluded.company_name,exchange=excluded.exchange,sector=excluded.sector,listing_status=excluded.listing_status,source=excluded.source,source_updated_at=excluded.source_updated_at").bind(symbol,companyName,String(r.exchange || "BURSA"),r.sector || null,r.listing_status || "active",String(payload.source || "Bursa directory import"),now);
          }).filter(Boolean) as D1PreparedStatement[];
          if (batch.length) { await env.DB.batch(batch); imported += batch.length; }
        }
        return json({imported,source:payload.source || "Bursa directory import",asOf:now});
      } catch (e) { return json({error:String(e)},400); }
    }
    if (url.pathname==="/api/universe") {
      const market = url.searchParams.get("market")==="US" ? "US" : "MY";
      try {
        await ensureSchema(env);
        // INTENTIONAL: this is a read-only legacy/master-data endpoint. US candidate selection belongs to MFI;
        // never repopulate the displayed US universe from the broad SEC ticker directory.
        const result = await env.DB.prepare("SELECT * FROM stock_master WHERE market=? AND listing_status='active' ORDER BY company_name").bind(market).all();
        return json({market,stocks:result.results,count:result.results.length});
      } catch (e) { return json({market,stocks:[],count:0,error:String(e)},502); }
    }
    if (url.pathname==="/api/stocks") {
      const market = url.searchParams.get("market")==="US" ? "US" : "MY";
      let refresh: any = null;
      try {
        await ensureSchema(env);
        if (url.searchParams.get("refresh")==="1") {
          try {
            refresh = await refreshQuotes(env, market);
          } catch (error) {
            // INTENTIONAL: D1 write-quota exhaustion or quote-provider failure must not block cached reads.
            refresh = {updated:0,failed:0,remaining:null,error:String(error)};
          }
        }
        // INTENTIONAL: SEC fundamentals are authoritative for US calculations. The snapshot is a quote/cache projection and can lag the fundamentals table; prefer same-market-cap SEC ratios and derive the displayed status from the SEC record.
        const result = await env.DB.prepare("SELECT m.symbol,m.market,m.company_name,m.currency,q.price,q.change_percent,q.market_cap,CASE WHEN f.status='calculated' AND f.market_cap IS q.market_cap THEN f.earnings_yield WHEN f.status='calculated' THEN NULL ELSE q.earnings_yield END AS earnings_yield,CASE WHEN f.status='calculated' AND f.market_cap IS q.market_cap THEN f.return_on_capital WHEN f.status='calculated' THEN NULL ELSE q.return_on_capital END AS return_on_capital,q.magic_formula_rank,f.fiscal_period,f.filed_at,f.status AS fundamentals_status,f.source AS fundamentals_source,f.ebit AS fundamentals_ebit,f.current_assets AS fundamentals_current_assets,f.current_liabilities AS fundamentals_current_liabilities,f.net_ppe AS fundamentals_net_ppe,f.total_debt AS fundamentals_total_debt,f.cash AS fundamentals_cash,(SELECT GROUP_CONCAT(um2.source,'|') FROM stock_universe_membership um2 WHERE um2.market=m.market AND um2.symbol=m.symbol AND um2.active=1) AS universe_sources_raw,COALESCE(q.shariah_status,'unverified') AS shariah_status,q.shariah_source,q.shariah_as_of,CASE WHEN f.status='calculated' AND f.market_cap IS q.market_cap THEN 'fundamentals_calculated' WHEN f.status='calculated' THEN 'fundamentals_stale_market_cap' WHEN f.status='stale_fiscal_period' THEN 'fundamentals_stale' WHEN f.status='missing_required_facts' THEN 'fundamentals_incomplete' WHEN f.status='negative_invested_capital' THEN 'fundamentals_negative_invested_capital' WHEN f.status='zero_invested_capital' THEN 'fundamentals_zero_invested_capital' ELSE COALESCE(q.data_status,'awaiting_quote') END AS data_status,q.provider,q.updated_at FROM stock_master m LEFT JOIN stock_snapshot q ON q.symbol=m.symbol AND q.market=m.market LEFT JOIN stock_fundamentals f ON f.symbol=m.symbol AND f.market=m.market WHERE m.market=? AND m.listing_status='active' AND (m.market!='US' OR EXISTS (SELECT 1 FROM stock_universe_membership um WHERE um.market='US' AND um.symbol=m.symbol AND um.active=1)) ORDER BY COALESCE(q.magic_formula_rank,999),m.company_name").bind(market).all();
        const latest = await env.DB.prepare("SELECT MAX(updated_at) AS updated_at FROM stock_snapshot WHERE market=?").bind(market).first<{updated_at:string|null}>();
        // INTENTIONAL: preserve the distinction between an explicit numeric zero and an absent SEC fact.
        // Company Facts omits custom-tagged and dimension-specific observations, so missing fields
        // are described as not found in this standard dataset, never as zero or proof of non-disclosure.
        const fundamentalsFields=[["EBIT","fundamentals_ebit"],["Current assets","fundamentals_current_assets"],["Current liabilities","fundamentals_current_liabilities"],["Net PP&E","fundamentals_net_ppe"],["Total debt","fundamentals_total_debt"],["Cash","fundamentals_cash"]] as const;
        const stocks=result.results.map((row:any)=>{
          const missing:string[]=[];
          const zero:string[]=[];
          for(const [label,key] of fundamentalsFields){
            if(row[key]==null) missing.push(label);
            else if(row[key]===0) zero.push(label);
          }
          const {fundamentals_ebit,fundamentals_current_assets,fundamentals_current_liabilities,fundamentals_net_ppe,fundamentals_total_debt,fundamentals_cash,universe_sources_raw,...stock}=row;
          const universe_sources=universe_sources_raw?String(universe_sources_raw).split("|").sort():[];
          return {...stock,universe_sources,fundamentals_missing_fields:row.fundamentals_status==="missing_required_facts"?missing:[],fundamentals_zero_fields:zero};
        });
        return json({market,stocks,updatedAt:latest?.updated_at ?? null,sourceStatus:stocks.some((row:any)=>row.price!=null)?"Quote cache connected":"Waiting for scheduled quote sync",refresh});
      } catch (error) {
        return json({market,stocks:[],updatedAt:null,sourceStatus:"Cached stock read failed",error:String(error),refresh},503);
      }
    }
    return env.ASSETS.fetch(request);
  },
  async scheduled(controller: ScheduledController, env: Env, ctx: ExecutionContext) {
    if (controller.cron === "*/30 * * * *") {
      // INTENTIONAL: SEC ingestion is its own cron lane. Return after scheduling it so this
      // invocation does not also trigger a quote refresh for an unrelated market.
      // SEC ingestion runs independently from browser visits, in bounded batches.
      ctx.waitUntil(syncUsFundamentals(env, 10));
      return;
    }
    const market = controller.cron.startsWith("17 ") ? "MY" : "US";
    ctx.waitUntil(refreshQuotes(env, market));
  }
};
